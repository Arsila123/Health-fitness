export type FitnessGoal = 'weight_loss' | 'weight_gain' | 'muscle_building' | 'stay_fit';

export type Gender = 'male' | 'female' | 'other';

export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';

export type PriceLevel = '$' | '$$' | '$$$';

export type StoreCategory = 'salad_bar' | 'juice_shop' | 'protein_store' | 'healthy_restaurant';

export interface UserLocation {
  address: string;
  city: string;
  state?: string;
  zipCode?: string;
  lat: number;
  lng: number;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  age: number;
  gender: Gender;
  heightCm: number;
  weightKg: number;
  fitnessGoal: FitnessGoal;
  activityLevel: ActivityLevel;
  location: UserLocation;
  dietaryPreference: 'all' | 'high_protein' | 'vegan' | 'vegetarian' | 'keto' | 'low_carb';
  budgetPreference: PriceLevel;
  avatarUrl?: string;
  createdAt: string;
}

export interface BMIMetrics {
  bmi: number;
  category: 'Underweight' | 'Normal weight' | 'Overweight' | 'Obese';
  color: string;
  idealWeightMinKg: number;
  idealWeightMaxKg: number;
  bmr: number; // Basal Metabolic Rate
  tdee: number; // Total Daily Energy Expenditure
  targetCalories: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
  waterLiters: number;
  trainerNote: string;
}

export interface BudgetItem {
  id: string;
  name: string;
  price: string;
  priceValue: number;
  calories?: number;
  proteinG?: number;
  description?: string;
  isPopular?: boolean;
}

export interface HealthyStore {
  id: string;
  name: string;
  category: StoreCategory;
  address: string;
  city: string;
  lat: number;
  lng: number;
  rating: number;
  reviewCount: number;
  priceLevel: PriceLevel;
  distanceKm: number;
  isOpen: boolean;
  phone?: string;
  website?: string;
  specialties: string[];
  budgetItems: BudgetItem[];
  imageUrl: string;
  discountNote?: string;
}

export interface AuthState {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface TrainerAdviceResponse {
  advice: string;
  suggestedMacros: {
    calories: number;
    proteinG: number;
    carbsG: number;
    fatG: number;
  };
  budgetTips: string[];
  recommendedMeals?: {
    meal: string;
    description: string;
    approxCost: string;
  }[];
}

export interface DiabetesReading {
  id: string;
  timestamp: string;
  type: 'fasting' | 'post_meal' | 'random';
  glucoseMgDl: number;
  notes?: string;
}

export interface DiabetesRiskFactors {
  fastingGlucoseMgDl?: number;
  postMealGlucoseMgDl?: number;
  hba1cPercent?: number;
  systolicBp?: number;
  diastolicBp?: number;
  familyHistory: boolean;
  highBpHistory: boolean;
  physicalInactivity: boolean;
  gestationalDiabetesHistory?: boolean;
}

export interface DiabetesReportResponse {
  riskAssessment: {
    level: 'Low Risk' | 'Pre-Diabetes / Borderline' | 'Diabetes Managed' | 'High Risk / Uncontrolled';
    score: number; // 0-10
    summary: string;
  };
  glycemicIndexGuideline: {
    maxCarbsPerMealG: number;
    dailyFiberTargetG: number;
    glycemicLoadCap: string;
  };
  clinicalAdvice: string;
  budgetLowGiFoods: {
    food: string;
    giRating: number;
    approxPrice: string;
    glycemicBenefit: string;
  }[];
  recommendedLowGiMeals: {
    meal: string;
    description: string;
    carbsG: number;
    proteinG: number;
    approxCost: string;
  }[];
  warningFlags?: string[];
}

