import { HealthyStore } from '../types';

export const INITIAL_HEALTHY_STORES: HealthyStore[] = [
  {
    id: 'store-1',
    name: 'Green Leaf Salad Bar & Protein Kitchen',
    category: 'salad_bar',
    address: '142 Healthy Way, Suite A',
    city: 'New York, NY',
    lat: 40.7128,
    lng: -74.0060,
    rating: 4.8,
    reviewCount: 342,
    priceLevel: '$',
    distanceKm: 0.6,
    isOpen: true,
    phone: '(212) 555-0192',
    website: 'https://greenleafsaladbar.example.com',
    specialties: ['Custom $8.99 Salad Bowls', 'Warm Grain Protein Bowls', 'Organic House Dressings'],
    imageUrl: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80',
    discountNote: '10% Off for Student & Gym Members',
    budgetItems: [
      {
        id: 'bi-1',
        name: 'Build-Your-Own Green Salad Bowl',
        price: '$8.49',
        priceValue: 8.49,
        calories: 380,
        proteinG: 22,
        description: 'Choice of kale/spinach, grilled chicken breast, chickpea, cucumber & lemon vinaigrette.',
        isPopular: true
      },
      {
        id: 'bi-2',
        name: 'Quinoa & Roast Veggie Power Bowl',
        price: '$9.99',
        priceValue: 9.99,
        calories: 460,
        proteinG: 18,
        description: 'Tri-color quinoa, roasted sweet potato, broccoli, avocado slice & tahini drip.'
      },
      {
        id: 'bi-3',
        name: 'Chipotle Lime Chicken Bowl',
        price: '$10.50',
        priceValue: 10.50,
        calories: 520,
        proteinG: 42,
        description: 'Lean chicken breast, black beans, brown rice, salsa fresco & cilantro lime dressing.',
        isPopular: true
      }
    ]
  },
  {
    id: 'store-2',
    name: 'Pulse & Squeeze Juice Bar',
    category: 'juice_shop',
    address: '88 Refreshment Blvd',
    city: 'New York, NY',
    lat: 40.7180,
    lng: -74.0010,
    rating: 4.9,
    reviewCount: 218,
    priceLevel: '$',
    distanceKm: 1.1,
    isOpen: true,
    phone: '(212) 555-0841',
    specialties: ['Cold-Pressed $5 Green Juices', 'Ginger Immune Shots $2', 'Acai Protein Smoothies'],
    imageUrl: 'https://images.unsplash.com/photo-1622597467836-f3285f2131b8?auto=format&fit=crop&w=800&q=80',
    discountNote: 'Free Booster Shot with Any $8+ Smoothie',
    budgetItems: [
      {
        id: 'bi-4',
        name: 'Daily Detox Green Juice (16oz)',
        price: '$5.50',
        priceValue: 5.50,
        calories: 110,
        proteinG: 3,
        description: 'Cucumber, celery, green apple, spinach, lemon & fresh ginger boost.',
        isPopular: true
      },
      {
        id: 'bi-5',
        name: 'Peanut Butter Banana Whey Smoothie',
        price: '$6.99',
        priceValue: 6.99,
        calories: 410,
        proteinG: 30,
        description: 'Almond milk, 100% whey isolate, banana, natural peanut butter & cinnamon.',
        isPopular: true
      },
      {
        id: 'bi-6',
        name: 'Immunity Ginger & Turmeric Shot (2oz)',
        price: '$2.50',
        priceValue: 2.50,
        calories: 25,
        proteinG: 0,
        description: 'Raw ginger juice, turmeric, cayenne pepper & organic apple cider vinegar.'
      }
    ]
  },
  {
    id: 'store-3',
    name: 'NutriVault Protein & Fitness Nutrition',
    category: 'protein_store',
    address: '304 Muscle Avenue',
    city: 'New York, NY',
    lat: 40.7100,
    lng: -74.0120,
    rating: 4.7,
    reviewCount: 189,
    priceLevel: '$$',
    distanceKm: 1.8,
    isOpen: true,
    phone: '(212) 555-9321',
    specialties: ['Bulk Whey & Plant Isolate', 'Budget High-Protein Snacks', 'Creatine & Electrolytes'],
    imageUrl: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?auto=format&fit=crop&w=800&q=80',
    discountNote: 'Buy 1 Get 1 50% Off Protein Bars',
    budgetItems: [
      {
        id: 'bi-7',
        name: 'Budget Whey Isolate Tub (2lb)',
        price: '$29.99',
        priceValue: 29.99,
        proteinG: 25,
        description: 'Pure micro-filtered whey protein. 30 servings at under $1.00 per scoop!',
        isPopular: true
      },
      {
        id: 'bi-8',
        name: 'Crispy Cookie Protein Bar (Single)',
        price: '$2.25',
        priceValue: 2.25,
        calories: 200,
        proteinG: 20,
        description: 'Low sugar, high fiber protein snack on the go.'
      },
      {
        id: 'bi-9',
        name: 'Micronized Creatine Monohydrate (250g)',
        price: '$14.99',
        priceValue: 14.99,
        description: '100% pure unflavored creatine for muscle strength & cellular recovery.'
      }
    ]
  },
  {
    id: 'store-4',
    name: 'The Good Life Budget Grill & Meal Prep',
    category: 'healthy_restaurant',
    address: '512 Vitality Street',
    city: 'New York, NY',
    lat: 40.7230,
    lng: -73.9980,
    rating: 4.9,
    reviewCount: 412,
    priceLevel: '$',
    distanceKm: 1.4,
    isOpen: true,
    phone: '(212) 555-7733',
    specialties: ['$9 Meal Prep Boxes', 'Grass-Fed Steak & Rice', 'Low Calorie High Volume Bowls'],
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    discountNote: 'Weekly 5-Meal Prep Box Deal: Only $42.50',
    budgetItems: [
      {
        id: 'bi-10',
        name: 'Grilled Salmon & Steamed Broccoli Plate',
        price: '$11.99',
        priceValue: 11.99,
        calories: 480,
        proteinG: 38,
        description: 'Wild salmon fillet, lemon garlic butter, steamed broccoli & brown rice.',
        isPopular: true
      },
      {
        id: 'bi-11',
        name: 'High-Protein Turkey Taco Bowl',
        price: '$8.99',
        priceValue: 8.99,
        calories: 420,
        proteinG: 35,
        description: 'Seasoned 93% lean ground turkey, roasted corn, black beans & pico de gallo.',
        isPopular: true
      },
      {
        id: 'bi-12',
        name: 'Macro-Balanced Egg & Avocado Wrap',
        price: '$6.50',
        priceValue: 6.50,
        calories: 360,
        proteinG: 22,
        description: 'Whole wheat wrap, 3 egg whites, spinach, avocado & light feta cheese.'
      }
    ]
  },
  {
    id: 'store-5',
    name: 'SunRise Organic Juice & Smoothie Bar',
    category: 'juice_shop',
    address: '22 Ocean Breeze Lane',
    city: 'New York, NY',
    lat: 40.7050,
    lng: -74.0150,
    rating: 4.6,
    reviewCount: 154,
    priceLevel: '$',
    distanceKm: 2.2,
    isOpen: true,
    phone: '(212) 555-4102',
    specialties: ['Matcha Protein Lattes', 'Dragonfruit Bowls', 'Cold Shot Sampler'],
    imageUrl: 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=800&q=80',
    budgetItems: [
      {
        id: 'bi-13',
        name: 'Berry Blast Antioxidant Smoothie',
        price: '$5.99',
        priceValue: 5.99,
        calories: 220,
        proteinG: 8,
        description: 'Blueberries, strawberries, coconut water, chia seeds & flax.'
      },
      {
        id: 'bi-14',
        name: 'Budget Acai Energy Bowl',
        price: '$7.99',
        priceValue: 7.99,
        calories: 350,
        proteinG: 12,
        description: 'Organic acai blend topped with hemp seed granola, banana slices & honey.',
        isPopular: true
      }
    ]
  },
  {
    id: 'store-6',
    name: 'Atlas Muscle & Supplement Hub',
    category: 'protein_store',
    address: '900 Champion Parkway',
    city: 'New York, NY',
    lat: 40.7300,
    lng: -73.9900,
    rating: 4.8,
    reviewCount: 267,
    priceLevel: '$$',
    distanceKm: 2.9,
    isOpen: true,
    phone: '(212) 555-8822',
    specialties: ['Vegan Pea Protein', 'Zero Sugar Energy Drinks', 'Glutamine & BCAA Powder'],
    imageUrl: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?auto=format&fit=crop&w=800&q=80',
    budgetItems: [
      {
        id: 'bi-15',
        name: 'Organic Plant-Based Protein Powder (2.2lb)',
        price: '$27.99',
        priceValue: 27.99,
        proteinG: 24,
        description: 'Non-GMO pea & brown rice protein blend with digestive enzymes.',
        isPopular: true
      },
      {
        id: 'bi-16',
        name: 'Zero Calorie BCAA Amino Drink Mix (30 Servings)',
        price: '$18.50',
        priceValue: 18.50,
        description: 'Branch chain amino acids for intra-workout hydration & reduced soreness.'
      }
    ]
  }
];

// Helper to calculate approximate distance in km given lat1, lng1, lat2, lng2
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the earth in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return Number(d.toFixed(1));
}
