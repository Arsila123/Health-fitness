import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { UserProfileSection } from './components/UserProfileSection';
import { StoreFinder } from './components/StoreFinder';
import { TrainerCoach } from './components/TrainerCoach';
import { BudgetGuide } from './components/BudgetGuide';
import { DiabetesReport } from './components/DiabetesReport';
import { AuthModal } from './components/AuthModal';
import { UtensilsCrossed, Heart, Shield, Sparkles, MapPin } from 'lucide-react';

function MainApp() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'stores' | 'coach' | 'guide' | 'diabetes'>('dashboard');
  const [authModalState, setAuthModalState] = useState<{ isOpen: boolean; mode: 'login' | 'signup' | 'forgot' }>({
    isOpen: false,
    mode: 'login',
  });

  const handleOpenAuthModal = (mode: 'login' | 'signup' | 'forgot') => {
    setAuthModalState({ isOpen: true, mode });
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7] text-[#334021] font-sans flex flex-col selection:bg-[#556b2f] selection:text-[#fdfbf7]">
      
      {/* Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuthModal={handleOpenAuthModal}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <UserProfileSection
            onNavigateToCoach={() => setActiveTab('coach')}
            onNavigateToStores={() => setActiveTab('stores')}
            onNavigateToDiabetes={() => setActiveTab('diabetes')}
          />
        )}

        {activeTab === 'stores' && <StoreFinder />}

        {activeTab === 'coach' && <TrainerCoach />}

        {activeTab === 'diabetes' && <DiabetesReport />}

        {activeTab === 'guide' && <BudgetGuide />}
      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalState.isOpen}
        initialMode={authModalState.mode}
        onClose={() => setAuthModalState({ ...authModalState, isOpen: false })}
      />

      {/* Footer */}
      <footer className="bg-[#334021] text-[#e5e0d1] border-t border-[#334021] py-10 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-[#fdfbf7]/15 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#556b2f] text-[#fdfbf7] flex items-center justify-center font-bold">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
              <div>
                <span className="font-serif font-bold text-[#fdfbf7] text-base tracking-tight">
                  Good Food, Good Life
                </span>
                <p className="text-xs text-[#e5e0d1]/80">NutriFit & Budget Healthy Food Finder</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-[#e5e0d1]">
              <button onClick={() => setActiveTab('dashboard')} className="hover:text-[#fdfbf7] cursor-pointer">Dashboard & BMI</button>
              <button onClick={() => setActiveTab('stores')} className="hover:text-[#fdfbf7] cursor-pointer">Store Finder Map</button>
              <button onClick={() => setActiveTab('coach')} className="hover:text-[#fdfbf7] cursor-pointer">AI Trainer Coach</button>
              <button onClick={() => setActiveTab('diabetes')} className="hover:text-[#fdfbf7] cursor-pointer">Diabetes Report</button>
              <button onClick={() => setActiveTab('guide')} className="hover:text-[#fdfbf7] cursor-pointer">Nutrition Guide</button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#e5e0d1]/70">
            <p>© {new Date().getFullYear()} Good Food, Good Life. Designed by Senior Clinical Fitness & Nutrition Specialists (12 Yrs Exp).</p>
            <p className="flex items-center gap-1">
              <span>Crafted for high performance & budget health</span>
              <Heart className="w-3.5 h-3.5 text-[#e5e0d1] fill-[#e5e0d1] ml-1" />
            </p>
          </div>
        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
