import React, { useState } from 'react';
import { APIProvider, Map, AdvancedMarker, Pin, InfoWindow } from '@vis.gl/react-google-maps';
import { HealthyStore } from '../types';
import { MapPin, Navigation, ExternalLink, Star, DollarSign, Clock, Phone } from 'lucide-react';

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';

const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

interface MapContainerProps {
  stores: HealthyStore[];
  selectedStore: HealthyStore | null;
  onSelectStore: (store: HealthyStore | null) => void;
  centerLat: number;
  centerLng: number;
}

export const MapContainer: React.FC<MapContainerProps> = ({
  stores,
  selectedStore,
  onSelectStore,
  centerLat,
  centerLng,
}) => {
  const [activeMarkerId, setActiveMarkerId] = useState<string | null>(selectedStore?.id || null);

  const categoryColors: Record<string, string> = {
    salad_bar: '#556b2f', // olive green
    juice_shop: '#8c826b', // warm taupe
    protein_store: '#334021', // deep olive
    healthy_restaurant: '#6e7e52', // light sage
  };

  if (!hasValidKey) {
    // Interactive Map Fallback Visualizer when Google Maps API Key is not configured yet
    return (
      <div className="relative w-full h-[480px] sm:h-[560px] bg-[#334021] rounded-3xl overflow-hidden border border-[#334021] shadow-xl flex flex-col justify-between p-4 sm:p-6 text-[#fdfbf7] font-sans">
        
        {/* Background Grid Pattern & Map Graphic */}
        <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#e5e0d1_1px,transparent_1px)] [background-size:16px_16px]"></div>

        {/* Top Info Overlay */}
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 bg-[#334021]/90 backdrop-blur-md p-3 sm:p-4 rounded-2xl border border-[#fdfbf7]/20">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#556b2f] animate-pulse border border-[#e5e0d1]"></div>
            <span className="text-xs font-bold text-[#fdfbf7]">
              Interactive Healthy Food Map ({stores.length} Nearby Spots Found)
            </span>
          </div>

          <a
            href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] font-bold text-[#e5e0d1] hover:underline flex items-center gap-1"
          >
            <span>Optional: Enable Live Google Maps Key</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Simulated Map Markers Grid Canvas */}
        <div className="relative z-10 my-auto grid grid-cols-2 sm:grid-cols-3 gap-3 p-2">
          {stores.slice(0, 6).map((store) => (
            <div
              key={store.id}
              onClick={() => onSelectStore(store)}
              className={`p-3.5 rounded-2xl cursor-pointer transition-all border ${
                selectedStore?.id === store.id
                  ? 'bg-[#556b2f] border-[#e5e0d1] text-[#fdfbf7] scale-102 shadow-lg ring-2 ring-[#e5e0d1]/30'
                  : 'bg-[#fdfbf7]/10 hover:bg-[#fdfbf7]/20 border-[#fdfbf7]/20 text-[#fdfbf7]'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-full border border-[#fdfbf7]/40"
                  style={{ backgroundColor: categoryColors[store.category] || '#556b2f' }}
                ></span>
                <span className="text-[10px] font-bold text-[#fdfbf7] bg-[#fdfbf7]/15 px-1.5 py-0.5 rounded border border-[#fdfbf7]/20">
                  {store.priceLevel} Budget
                </span>
              </div>
              <h4 className="font-serif text-xs font-bold truncate">{store.name}</h4>
              <p className="text-[10px] text-[#e5e0d1] truncate mt-0.5">{store.address}</p>
              
              <div className="mt-2 flex items-center justify-between text-[10px] text-[#e5e0d1]">
                <span className="flex items-center gap-1 font-bold text-[#fdfbf7]">
                  <Star className="w-3 h-3 fill-[#e5e0d1] text-[#e5e0d1]" />
                  {store.rating}
                </span>
                <span>{store.distanceKm} km away</span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Location Prompt */}
        <div className="relative z-10 bg-[#334021]/90 backdrop-blur-md p-3 rounded-2xl border border-[#fdfbf7]/20 flex items-center justify-between text-xs">
          <span className="text-[#e5e0d1] font-medium">
            📍 Center: {centerLat.toFixed(3)}, {centerLng.toFixed(3)} (Click any spot card to view menu & directions)
          </span>
          <button
            onClick={() => {
              if (stores.length > 0) onSelectStore(stores[0]);
            }}
            className="px-3 py-1 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold rounded-xl text-[11px] transition-colors cursor-pointer border border-[#e5e0d1]/30"
          >
            Explore First Spot
          </button>
        </div>

      </div>
    );
  }

  // Real Google Maps Provider mode when process.env.GOOGLE_MAPS_PLATFORM_KEY exists
  return (
    <div className="w-full h-[480px] sm:h-[560px] rounded-3xl overflow-hidden border border-stone-200 shadow-xl relative">
      <APIProvider apiKey={API_KEY} version="weekly">
        <Map
          defaultCenter={{ lat: centerLat, lng: centerLng }}
          defaultZoom={13}
          mapId="GOOD_LIFE_HEALTHY_STORES_MAP"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          style={{ width: '100%', height: '100%' }}
        >
          {stores.map((store) => (
            <React.Fragment key={store.id}>
              <AdvancedMarker
                position={{ lat: store.lat, lng: store.lng }}
                onClick={() => {
                  onSelectStore(store);
                  setActiveMarkerId(store.id);
                }}
              >
                <Pin
                  background={categoryColors[store.category] || '#10b981'}
                  borderColor="#ffffff"
                  glyphColor="#ffffff"
                />
              </AdvancedMarker>

              {activeMarkerId === store.id && (
                <InfoWindow
                  position={{ lat: store.lat, lng: store.lng }}
                  onCloseClick={() => setActiveMarkerId(null)}
                >
                  <div className="p-2 max-w-xs text-stone-900">
                    <span className="px-2 py-0.5 text-[10px] font-extrabold bg-emerald-100 text-emerald-800 rounded uppercase tracking-wider inline-block mb-1">
                      {store.category.replace('_', ' ')} • {store.priceLevel}
                    </span>
                    <h4 className="text-xs font-black">{store.name}</h4>
                    <p className="text-[11px] text-stone-600 mt-0.5">{store.address}</p>
                    
                    <div className="mt-2 flex items-center justify-between text-xs pt-1 border-t border-stone-100">
                      <span className="font-bold text-emerald-700">★ {store.rating} ({store.reviewCount})</span>
                      <a
                        href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${store.name}, ${store.address}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[10px] font-bold text-blue-600 hover:underline"
                      >
                        Directions →
                      </a>
                    </div>
                  </div>
                </InfoWindow>
              )}
            </React.Fragment>
          ))}
        </Map>
      </APIProvider>
    </div>
  );
};
