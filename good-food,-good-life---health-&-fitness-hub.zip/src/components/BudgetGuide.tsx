import React from 'react';
import { 
  BookOpen, 
  DollarSign, 
  CheckCircle2, 
  Award, 
  Utensils, 
  Sparkles, 
  Zap, 
  ShieldCheck,
  ShoppingBag,
  HelpCircle
} from 'lucide-react';

export const BudgetGuide: React.FC = () => {
  const groceryStaples = [
    { food: 'Eggs (Whole)', price: '$2.99 / dozen', protein: '72g protein', tip: 'Highest biological value protein. Great for breakfast or dinner.' },
    { food: 'Canned Salmon & Tuna', price: '$1.99 / can', protein: '30g protein', tip: 'Zero prep required. Rich in Omega-3 fatty acids for joint health.' },
    { food: 'Greek Yogurt (Plain)', price: '$3.49 / 32oz', protein: '90g protein', tip: 'High casein protein for overnight recovery and gut microbiome.' },
    { food: 'Dry Lentils & Chickpeas', price: '$1.49 / lb', protein: '110g protein', tip: 'Extremely cheap fiber & protein base for salads and soups.' },
    { food: 'Peanut Butter (100% Natural)', price: '$2.99 / jar', protein: '112g protein', tip: 'Dense healthy calories for weight gain and energy.' },
    { food: 'Rolled Oats', price: '$2.49 / tub', protein: '60g protein', tip: 'Complex carbs with beta-glucan fiber to keep cholesterol low.' },
  ];

  const FAQs = [
    {
      q: 'How can I meet my protein goal without expensive steak and salmon every day?',
      a: 'In 12 years of coaching, I recommend eggs, canned fish, Greek yogurt, chicken leg quarters, and dry legumes. You get 120g-150g of high-quality protein for under $6 per day!'
    },
    {
      q: 'Are salad bars and juice shops actually budget friendly?',
      a: 'Yes, if you order strategically! Use our Store Finder to look for $8-$9 build-your-own bowls and $5 green juice specials. They offer high micro-nutrient density without buying 10 separate vegetables.'
    },
    {
      q: 'How does BMI affect my caloric target?',
      a: 'BMI gives a fast index of weight relative to height. If your BMI is >25, aim for a 500 kcal deficit. If your BMI is <18.5, aim for a 500 kcal surplus. Our Dashboard calculates your exact BMR and TDEE.'
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in pb-12 font-sans">
      
      {/* Hero Banner */}
      <div className="bg-[#334021] text-[#fdfbf7] rounded-3xl p-6 sm:p-8 border border-[#334021] shadow-lg relative overflow-hidden">
        <div className="space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#fdfbf7]/10 text-[#fdfbf7] text-xs font-bold border border-[#fdfbf7]/20">
            <BookOpen className="w-3.5 h-3.5 text-[#e5e0d1]" />
            <span>Senior Trainer Budget Fitness Guide</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#fdfbf7]">
            High-Protein Healthy Eating on a Budget
          </h1>
          <p className="text-[#e5e0d1] text-xs sm:text-sm max-w-2xl leading-relaxed">
            Eating clean and reaching your fitness goals doesn't require expensive meal deliveries. Here is our 12-year clinical guide to budget protein shopping, salad bar hacks, and meal prep.
          </p>
        </div>
      </div>

      {/* Grocery Staples Cheat Sheet */}
      <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-4">
        <div className="flex items-center gap-3 border-b border-[#e5e0d1] pb-4">
          <div className="w-10 h-10 rounded-2xl bg-[#556b2f]/20 text-[#556b2f] flex items-center justify-center font-bold">
            <ShoppingBag className="w-5 h-5 text-[#556b2f]" />
          </div>
          <div>
            <h2 className="font-serif text-base font-bold text-[#334021]">Highest Protein-Per-Dollar Grocery Cheat Sheet</h2>
            <p className="text-[11px] text-[#8c826b]">Coach Marcus's Top Budget Choices</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {groceryStaples.map((item, idx) => (
            <div key={idx} className="p-4 bg-[#e5e0d1]/20 rounded-2xl border border-[#e5e0d1] space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-serif text-xs font-bold text-[#334021]">{item.food}</span>
                <span className="text-xs font-bold text-[#fdfbf7] bg-[#556b2f] px-2 py-0.5 rounded border border-[#556b2f]">
                  {item.price}
                </span>
              </div>
              <p className="text-[11px] font-bold text-[#334021] bg-[#8c826b]/20 px-2 py-0.5 rounded inline-block">
                💪 Yields {item.protein}
              </p>
              <p className="text-[11px] text-[#8c826b] leading-relaxed">
                {item.tip}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* FAQs */}
      <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-4">
        <div className="flex items-center gap-3 border-b border-[#e5e0d1] pb-4">
          <div className="w-10 h-10 rounded-2xl bg-[#556b2f]/20 text-[#556b2f] flex items-center justify-center font-bold">
            <HelpCircle className="w-5 h-5 text-[#556b2f]" />
          </div>
          <div>
            <h2 className="font-serif text-base font-bold text-[#334021]">Frequently Asked Questions</h2>
            <p className="text-[11px] text-[#8c826b]">Clinical Advice for Real World Nutrition</p>
          </div>
        </div>

        <div className="space-y-3">
          {FAQs.map((faq, idx) => (
            <div key={idx} className="p-4 bg-[#e5e0d1]/20 rounded-2xl border border-[#e5e0d1] space-y-1.5">
              <h3 className="text-xs font-bold text-[#334021] flex items-center gap-2">
                <span className="text-[#556b2f] font-serif font-bold">Q:</span>
                <span>{faq.q}</span>
              </h3>
              <p className="text-xs text-[#8c826b] leading-relaxed pl-5">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
