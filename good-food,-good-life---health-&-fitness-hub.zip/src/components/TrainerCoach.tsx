import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { calculateBMIMetrics } from '../lib/bmi';
import { TrainerAdviceResponse } from '../types';
import { 
  Sparkles, 
  Send, 
  User, 
  Award, 
  DollarSign, 
  Flame, 
  Utensils, 
  CheckCircle2, 
  RefreshCw,
  BookOpen,
  Zap,
  Check
} from 'lucide-react';

export const TrainerCoach: React.FC = () => {
  const { user } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [adviceResponse, setAdviceResponse] = useState<TrainerAdviceResponse | null>(null);

  const bmiMetrics = calculateBMIMetrics(
    user?.weightKg || 74,
    user?.heightCm || 178,
    user?.age || 27,
    user?.gender || 'male',
    user?.fitnessGoal || 'muscle_building'
  );

  const suggestedQuestions = [
    `Create a 7-Day Budget Meal Plan ($10/day) for my ${user?.fitnessGoal?.replace('_', ' ') || 'muscle building'} goal.`,
    `What are the top 5 cheapest high-protein foods I can buy at my local stores?`,
    `How to optimize my post-workout nutrition for a BMI of ${bmiMetrics.bmi}?`,
    `Give me a 4-day workout and recovery split tailored to my profile.`,
  ];

  const handleGenerateAdvice = async (customPrompt?: string) => {
    const activePrompt = customPrompt || prompt;
    if (!activePrompt.trim()) return;

    setIsLoading(true);
    try {
      const res = await fetch('/api/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userProfile: {
            ...user,
            bmi: bmiMetrics.bmi,
          },
          prompt: activePrompt,
        }),
      });

      const data = await res.json();
      if (res.ok && data) {
        setAdviceResponse(data);
      } else {
        throw new Error(data.error || 'Server error');
      }
    } catch (err) {
      console.error('Error fetching trainer advice:', err);
      // Fallback structured trainer response
      setAdviceResponse({
        advice: `### Coach Marcus's Assessment:\nBased on your BMI of **${bmiMetrics.bmi}** (${bmiMetrics.category}) and your goal of **${user?.fitnessGoal?.replace('_', ' ')}**, here is your priority strategy:\n\n1. **Protein Target**: Consume **${bmiMetrics.proteinG}g** of protein daily split into 4 meals.\n2. **Hydration**: Drink **${bmiMetrics.waterLiters}L** of water throughout the day.\n3. **Budget Grocery Staples**: Focus on eggs ($2.99/dozen), Greek yogurt ($3.49/32oz), canned salmon ($2.50), dried black beans, and oats.`,
        suggestedMacros: {
          calories: bmiMetrics.targetCalories,
          proteinG: bmiMetrics.proteinG,
          carbsG: bmiMetrics.carbsG,
          fatG: bmiMetrics.fatG,
        },
        budgetTips: [
          'Buy whole eggs and canned legumes in bulk; they provide the lowest cost per gram of complete protein.',
          'Visit local juice bars and salad bars for lunch specials under $9.',
          'Cook complex carbs (brown rice, sweet potato) in batch twice a week.'
        ],
        recommendedMeals: [
          { meal: 'Breakfast Power Bowl', description: '3 Whole eggs, 1/2 cup rolled oats, 1 tbsp peanut butter', approxCost: '$1.80' },
          { meal: 'Post-Workout Lunch', description: '150g Grilled chicken breast, 1 cup brown rice, steamed broccoli', approxCost: '$2.90' },
          { meal: 'Budget High Protein Dinner', description: 'Canned tuna salad with avocado, chickpeas & olive oil', approxCost: '$2.40' }
        ]
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12 font-sans">
      
      {/* Hero Header */}
      <div className="bg-[#334021] text-[#fdfbf7] rounded-3xl p-6 sm:p-8 border border-[#334021] shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#fdfbf7]/10 text-[#fdfbf7] text-xs font-bold border border-[#fdfbf7]/20">
              <Sparkles className="w-3.5 h-3.5 text-[#e5e0d1]" />
              <span>Gemini 3.6 Flash Senior Fitness AI</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#fdfbf7]">
              Coach Marcus Vance (12 Years Experience)
            </h1>
            <p className="text-[#e5e0d1] text-xs sm:text-sm max-w-2xl leading-relaxed">
              Ask your dedicated senior trainer anything about budget meal planning, macro targets for your BMI ({bmiMetrics.bmi}), workout splits, or budget grocery strategy.
            </p>
          </div>

          <div className="p-4 bg-[#fdfbf7]/10 rounded-2xl border border-[#fdfbf7]/20 text-xs font-semibold space-y-1">
            <p className="text-[#fdfbf7] font-bold">Target Calories: {bmiMetrics.targetCalories} kcal</p>
            <p className="text-[#e5e0d1]">Protein: {bmiMetrics.proteinG}g / day</p>
            <p className="text-[#e5e0d1] text-[11px]">Goal: {user?.fitnessGoal?.toUpperCase().replace('_', ' ')}</p>
          </div>
        </div>
      </div>

      {/* Interactive Chat & Suggestion Box */}
      <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-6">
        
        <div className="space-y-3">
          <label className="block text-xs font-bold text-[#334021] uppercase tracking-wider">
            Ask Coach Marcus a Specific Question or Choose Below
          </label>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. Create a $7/day muscle building meal plan with cheap grocery items..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleGenerateAdvice()}
              className="flex-1 px-4 py-3 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-2xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
            />
            <button
              onClick={() => handleGenerateAdvice()}
              disabled={isLoading || !prompt.trim()}
              className="px-6 py-3 bg-[#556b2f] hover:bg-[#435524] disabled:bg-[#8c826b]/30 text-[#fdfbf7] font-bold text-xs rounded-2xl shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span>{isLoading ? 'Analyzing...' : 'Ask Coach'}</span>
            </button>
          </div>

          {/* Quick Suggestion Pills */}
          <div className="space-y-2 pt-2">
            <span className="text-[11px] font-bold text-[#8c826b] uppercase tracking-wider block">
              Suggested Trainer Consultations:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {suggestedQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(q);
                    handleGenerateAdvice(q);
                  }}
                  className="p-3 text-left bg-[#e5e0d1]/30 hover:bg-[#e5e0d1]/60 text-[#334021] border border-[#e5e0d1] rounded-2xl text-xs font-medium transition-all cursor-pointer"
                >
                  💡 {q}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* AI Response Display */}
        {isLoading ? (
          <div className="p-12 text-center bg-[#e5e0d1]/20 rounded-3xl border border-[#e5e0d1] space-y-3">
            <div className="w-10 h-10 rounded-full bg-[#556b2f]/20 text-[#556b2f] mx-auto flex items-center justify-center animate-bounce">
              <Sparkles className="w-5 h-5" />
            </div>
            <p className="text-xs font-bold text-[#334021]">Coach Marcus is reviewing your metrics...</p>
            <p className="text-[11px] text-[#8c826b]">Calculating macros, budget food prices, and clinical routine for your BMI ({bmiMetrics.bmi}).</p>
          </div>
        ) : adviceResponse ? (
          <div className="space-y-6 pt-4 border-t border-[#e5e0d1] animate-fade-in">
            
            {/* Advice Header */}
            <div className="flex items-center justify-between bg-[#556b2f]/15 p-4 rounded-2xl border border-[#556b2f]/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#556b2f] text-[#fdfbf7] flex items-center justify-center font-bold">
                  👨‍⚕️
                </div>
                <div>
                  <h3 className="font-serif text-sm font-bold text-[#334021]">
                    Clinical Trainer Consultation Plan
                  </h3>
                  <p className="text-[11px] text-[#8c826b] font-medium">Curated for {user?.name || 'Client'}</p>
                </div>
              </div>

              <span className="px-3 py-1 bg-[#556b2f] text-[#fdfbf7] text-xs font-bold rounded-xl">
                12-Yr Veteran Advice
              </span>
            </div>

            {/* Advice Text */}
            <div className="prose text-xs leading-relaxed max-w-none bg-[#e5e0d1]/20 p-5 rounded-2xl border border-[#e5e0d1] text-[#334021] whitespace-pre-wrap">
              {adviceResponse.advice}
            </div>

            {/* Recommended Budget Meals Grid */}
            {adviceResponse.recommendedMeals && adviceResponse.recommendedMeals.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-[#334021] uppercase tracking-wider flex items-center gap-1.5">
                  <Utensils className="w-4 h-4 text-[#556b2f]" />
                  <span>Coach Marcus Recommended Budget Meal Prep</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {adviceResponse.recommendedMeals.map((meal, i) => (
                    <div key={i} className="p-4 bg-[#fdfbf7] rounded-2xl border border-[#e5e0d1] shadow-xs space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-serif text-xs font-bold text-[#334021]">{meal.meal}</span>
                        <span className="text-xs font-bold text-[#fdfbf7] bg-[#556b2f] px-2 py-0.5 rounded">
                          {meal.approxCost}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#8c826b] leading-normal">
                        {meal.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Budget Grocery Hacks */}
            {adviceResponse.budgetTips && adviceResponse.budgetTips.length > 0 && (
              <div className="bg-[#8c826b]/15 p-5 rounded-2xl border border-[#8c826b]/30 space-y-2">
                <h4 className="text-xs font-bold text-[#334021] uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-[#556b2f]" />
                  <span>Budget Grocery Secrets from 12 Years of Coaching</span>
                </h4>
                <ul className="space-y-1.5 text-xs text-[#334021]">
                  {adviceResponse.budgetTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="font-bold text-[#556b2f]">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

          </div>
        ) : null}

      </div>

    </div>
  );
};
