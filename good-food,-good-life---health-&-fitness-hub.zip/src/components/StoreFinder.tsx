import React, { useState, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { INITIAL_HEALTHY_STORES, calculateDistanceKm } from '../data/mockStores';
import { HealthyStore, StoreCategory, PriceLevel } from '../types';
import { MapContainer } from './MapContainer';
import { 
  Compass, 
  Search, 
  MapPin, 
  Filter, 
  Star, 
  DollarSign, 
  Phone, 
  Globe, 
  Clock, 
  Navigation, 
  ExternalLink, 
  X, 
  CheckCircle2, 
  Utensils, 
  Flame, 
  Sparkles,
  ShoppingBag
} from 'lucide-react';

export const StoreFinder: React.FC = () => {
  const { user, detectCurrentGPSLocation } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<StoreCategory | 'all'>('all');
  const [selectedPrice, setSelectedPrice] = useState<PriceLevel | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStore, setSelectedStore] = useState<HealthyStore | null>(null);
  const [isLocating, setIsLocating] = useState(false);

  const userLat = user?.location?.lat || 40.7128;
  const userLng = user?.location?.lng || -74.0060;

  // Calculate live distances & filter stores
  const filteredStores = useMemo(() => {
    return INITIAL_HEALTHY_STORES.map((store) => {
      const dist = calculateDistanceKm(userLat, userLng, store.lat, store.lng);
      return { ...store, distanceKm: dist };
    })
      .filter((store) => {
        // Category filter
        if (selectedCategory !== 'all' && store.category !== selectedCategory) return false;
        // Price filter
        if (selectedPrice !== 'all' && store.priceLevel !== selectedPrice) return false;
        // Search query filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = store.name.toLowerCase().includes(q);
          const matchAddress = store.address.toLowerCase().includes(q);
          const matchSpecialty = store.specialties.some((s) => s.toLowerCase().includes(q));
          const matchItem = store.budgetItems.some((bi) => bi.name.toLowerCase().includes(q) || bi.description?.toLowerCase().includes(q));
          return matchName || matchAddress || matchSpecialty || matchItem;
        }
        return true;
      })
      .sort((a, b) => a.distanceKm - b.distanceKm); // Sort nearest first
  }, [selectedCategory, selectedPrice, searchQuery, userLat, userLng]);

  const handleDetectGPS = async () => {
    setIsLocating(true);
    await detectCurrentGPSLocation();
    setIsLocating(false);
  };

  const categoryBadges: { id: StoreCategory | 'all'; label: string; icon: string }[] = [
    { id: 'all', label: 'All Spots', icon: '✨' },
    { id: 'salad_bar', label: 'Salad Bars', icon: '🥗' },
    { id: 'juice_shop', label: 'Juice Shops', icon: '🥤' },
    { id: 'protein_store', label: 'Protein Stores', icon: '🥩' },
    { id: 'healthy_restaurant', label: 'Budget Healthy Eats', icon: '🍲' },
  ];

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      
      {/* Header Banner */}
      <div className="bg-[#334021] text-[#fdfbf7] rounded-3xl p-6 sm:p-8 border border-[#334021] shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-[#556b2f]/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#fdfbf7]/10 text-[#fdfbf7] text-xs font-bold border border-[#fdfbf7]/20">
            <Compass className="w-3.5 h-3.5 text-[#e5e0d1]" />
            <span>Google Maps Healthy Food & Budget Store Finder</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#fdfbf7]">
            Find Nearby Salad Bars, Juice Shops & Protein Stores
          </h1>
          <p className="font-sans text-[#e5e0d1] text-xs sm:text-sm max-w-2xl leading-relaxed">
            Locate budget-friendly healthy eateries, fresh juice bars, salad bars, and supplement stores near <strong className="text-[#fdfbf7] underline">{user?.location?.city || 'your area'}</strong>. Every listed store includes budget-friendly meal picks under $10!
          </p>
        </div>
      </div>

      {/* Location & Search Control Bar */}
      <div className="bg-[#fdfbf7] rounded-3xl p-4 sm:p-5 border border-[#e5e0d1] shadow-sm space-y-4 font-sans">
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Location status & GPS button */}
          <div className="flex items-center gap-2 text-xs font-semibold text-[#334021] bg-[#e5e0d1]/30 p-2.5 rounded-2xl border border-[#e5e0d1]">
            <MapPin className="w-4 h-4 text-[#556b2f] shrink-0" />
            <span className="truncate">
              Location: <strong>{user?.location?.city || 'New York, NY'}</strong>
            </span>
            <button
              onClick={handleDetectGPS}
              disabled={isLocating}
              className="ml-auto px-3 py-1 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] text-[11px] font-bold rounded-xl transition-colors flex items-center gap-1 shrink-0 cursor-pointer"
            >
              <Navigation className={`w-3 h-3 ${isLocating ? 'animate-spin' : ''}`} />
              <span>{isLocating ? 'Locating...' : 'Use Current GPS'}</span>
            </button>
          </div>

          {/* Search bar input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#8c826b] absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search salad, acai, whey protein, $8 bowls..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-2xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-[#8c826b] hover:text-[#334021] cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

        </div>

        {/* Category & Budget Filters */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#e5e0d1]">
          
          {/* Category Badges */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
            {categoryBadges.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-[#556b2f] text-[#fdfbf7] shadow-sm'
                    : 'bg-[#e5e0d1]/40 text-[#334021] hover:bg-[#e5e0d1]/70'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Budget Price Filter */}
          <div className="flex items-center gap-2 text-xs font-bold text-[#334021]">
            <span className="text-[11px] uppercase tracking-wider text-[#8c826b]">Budget:</span>
            <div className="flex bg-[#e5e0d1]/40 p-1 rounded-xl border border-[#e5e0d1]">
              <button
                onClick={() => setSelectedPrice('all')}
                className={`px-2.5 py-1 rounded-lg text-xs transition-colors cursor-pointer ${
                  selectedPrice === 'all' ? 'bg-[#fdfbf7] text-[#334021] shadow-xs font-bold' : 'text-[#8c826b]'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedPrice('$')}
                className={`px-2.5 py-1 rounded-lg text-xs transition-colors cursor-pointer ${
                  selectedPrice === '$' ? 'bg-[#556b2f] text-[#fdfbf7] shadow-xs font-bold' : 'text-[#8c826b]'
                }`}
              >
                $ (Under $10)
              </button>
              <button
                onClick={() => setSelectedPrice('$$')}
                className={`px-2.5 py-1 rounded-lg text-xs transition-colors cursor-pointer ${
                  selectedPrice === '$$' ? 'bg-[#334021] text-[#fdfbf7] shadow-xs font-bold' : 'text-[#8c826b]'
                }`}
              >
                $$ (Under $18)
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Main Grid: Interactive Map (Top/Right) & Store List (Left/Bottom) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 font-sans">

        {/* LEFT LIST COLUMN (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-serif text-base font-bold text-[#334021]">
              Nearby Spots ({filteredStores.length})
            </h3>
            <span className="text-xs font-semibold text-[#8c826b]">
              Sorted by distance
            </span>
          </div>

          <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
            {filteredStores.length === 0 ? (
              <div className="p-8 text-center bg-[#fdfbf7] rounded-3xl border border-dashed border-[#e5e0d1] text-[#8c826b] space-y-2">
                <p className="text-sm font-bold text-[#334021]">No stores match your filters.</p>
                <p className="text-xs">Try clearing your search query or selecting "All Spots".</p>
                <button
                  onClick={() => { setSelectedCategory('all'); setSelectedPrice('all'); setSearchQuery(''); }}
                  className="px-4 py-2 bg-[#556b2f] text-[#fdfbf7] font-bold text-xs rounded-xl cursor-pointer"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              filteredStores.map((store) => (
                <div
                  key={store.id}
                  onClick={() => setSelectedStore(store)}
                  className={`p-4 rounded-3xl border transition-all cursor-pointer bg-[#fdfbf7] ${
                    selectedStore?.id === store.id
                      ? 'border-[#556b2f] shadow-md ring-2 ring-[#556b2f]/20'
                      : 'border-[#e5e0d1] hover:border-[#556b2f]/50 shadow-xs'
                  }`}
                >
                  <div className="flex gap-4">
                    <img
                      src={store.imageUrl}
                      alt={store.name}
                      className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shrink-0 border border-[#e5e0d1]"
                    />

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="px-2 py-0.5 text-[10px] font-bold bg-[#556b2f]/15 text-[#334021] rounded-md uppercase tracking-wider">
                          {store.category.replace('_', ' ')}
                        </span>
                        <span className="text-xs font-bold text-[#334021] bg-[#8c826b]/20 px-2 py-0.5 rounded-md">
                          {store.priceLevel}
                        </span>
                      </div>

                      <h4 className="font-serif text-sm font-bold text-[#334021] truncate">
                        {store.name}
                      </h4>

                      <p className="text-xs text-[#8c826b] truncate">
                        📍 {store.address}
                      </p>

                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="font-bold text-[#556b2f] flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 fill-[#8c826b] text-[#8c826b]" />
                          {store.rating} ({store.reviewCount})
                        </span>
                        <span className="font-bold text-[#8c826b] text-[11px]">
                          {store.distanceKm} km away
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Budget Highlight Tag */}
                  {store.discountNote && (
                    <div className="mt-3 p-2 bg-[#8c826b]/15 rounded-xl border border-[#8c826b]/30 text-[11px] font-bold text-[#334021] flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#556b2f] shrink-0" />
                      <span className="truncate">{store.discountNote}</span>
                    </div>
                  )}

                  {/* Top Budget Items preview */}
                  <div className="mt-2.5 pt-2 border-t border-[#e5e0d1] flex items-center justify-between text-[11px] text-[#8c826b]">
                    <span className="font-semibold text-[#8c826b]">
                      Popular Meal: <strong className="text-[#334021]">{store.budgetItems[0]?.name}</strong>
                    </span>
                    <span className="font-bold text-[#fdfbf7] bg-[#556b2f] px-2 py-0.5 rounded">
                      {store.budgetItems[0]?.price}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* RIGHT MAP COLUMN (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <MapContainer
            stores={filteredStores}
            selectedStore={selectedStore}
            onSelectStore={(store) => setSelectedStore(store)}
            centerLat={userLat}
            centerLng={userLng}
          />

          {/* Selected Store Quick Detail Bar */}
          {selectedStore && (
            <div className="p-5 bg-[#334021] text-[#fdfbf7] rounded-3xl border border-[#334021] shadow-xl space-y-4 animate-fade-in font-sans">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 text-[10px] font-bold bg-[#fdfbf7]/15 text-[#e5e0d1] rounded uppercase tracking-wider border border-[#fdfbf7]/20">
                      {selectedStore.category.replace('_', ' ')}
                    </span>
                    <span className="text-xs font-bold text-[#e5e0d1]">
                      ★ {selectedStore.rating} ({selectedStore.reviewCount} reviews)
                    </span>
                  </div>
                  <h3 className="font-serif text-lg font-bold text-[#fdfbf7] mt-1">
                    {selectedStore.name}
                  </h3>
                  <p className="text-xs text-[#e5e0d1]">
                    📍 {selectedStore.address}, {selectedStore.city}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedStore(null)}
                  className="p-1.5 text-[#e5e0d1] hover:text-white rounded-full bg-[#fdfbf7]/10 hover:bg-[#fdfbf7]/20 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Budget Healthy Items List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-[#e5e0d1] uppercase tracking-wider flex items-center gap-1.5">
                  <ShoppingBag className="w-3.5 h-3.5 text-[#e5e0d1]" />
                  <span>Budget-Friendly Healthy Menu Highlights</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedStore.budgetItems.map((item) => (
                    <div key={item.id} className="p-3 bg-[#fdfbf7]/10 rounded-2xl border border-[#fdfbf7]/15 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#fdfbf7] truncate">{item.name}</span>
                        <span className="text-xs font-bold text-[#fdfbf7] bg-[#556b2f] px-2 py-0.5 rounded border border-[#556b2f]">
                          {item.price}
                        </span>
                      </div>
                      {item.description && (
                        <p className="text-[10px] text-[#e5e0d1] line-clamp-2 leading-snug">
                          {item.description}
                        </p>
                      )}
                      {(item.calories || item.proteinG) && (
                        <div className="flex items-center gap-2 text-[10px] text-[#e5e0d1] font-semibold pt-1">
                          {item.calories && <span>🔥 {item.calories} kcal</span>}
                          {item.proteinG && <span>💪 {item.proteinG}g protein</span>}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Direct Actions */}
              <div className="flex items-center gap-3 pt-2">
                <a
                  href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${selectedStore.name}, ${selectedStore.address}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer border border-[#e5e0d1]/30"
                >
                  <Navigation className="w-4 h-4 text-[#e5e0d1]" />
                  <span>Get Directions on Google Maps</span>
                </a>

                {selectedStore.phone && (
                  <a
                    href={`tel:${selectedStore.phone}`}
                    className="px-4 py-3 bg-[#fdfbf7]/10 hover:bg-[#fdfbf7]/20 text-[#fdfbf7] border border-[#fdfbf7]/20 font-bold text-xs rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Phone className="w-4 h-4 text-[#e5e0d1]" />
                    <span>Call Store</span>
                  </a>
                )}
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
};
