import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { calculateBMIMetrics } from '../lib/bmi';
import { DiabetesReading, DiabetesRiskFactors, DiabetesReportResponse } from '../types';
import { 
  Activity, 
  Sparkles, 
  Heart, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  Plus, 
  FileText, 
  Printer, 
  Apple, 
  Utensils, 
  DollarSign, 
  TrendingDown, 
  RefreshCw,
  Clock,
  Trash2,
  ChevronRight,
  Info,
  Droplets
} from 'lucide-react';

export const DiabetesReport: React.FC = () => {
  const { user } = useAuth();

  // Calculate current BMI metrics for contextual diabetes risk assessment
  const bmiMetrics = calculateBMIMetrics(
    user?.weightKg || 74,
    user?.heightCm || 178,
    user?.age || 27,
    user?.gender || 'male',
    user?.fitnessGoal || 'stay_fit'
  );

  // Form inputs for blood glucose and risk factors
  const [fastingGlucose, setFastingGlucose] = useState<number>(98);
  const [postMealGlucose, setPostMealGlucose] = useState<number>(132);
  const [hba1c, setHba1c] = useState<number>(5.6);
  const [systolicBp, setSystolicBp] = useState<number>(120);
  const [diastolicBp, setDiastolicBp] = useState<number>(80);

  const [familyHistory, setFamilyHistory] = useState<boolean>(false);
  const [highBpHistory, setHighBpHistory] = useState<boolean>(false);
  const [physicalInactivity, setPhysicalInactivity] = useState<boolean>(false);

  // New reading input modal / inline form state
  const [newLogType, setNewLogType] = useState<'fasting' | 'post_meal' | 'random'>('fasting');
  const [newLogGlucose, setNewLogGlucose] = useState<number>(98);
  const [newLogNotes, setNewLogNotes] = useState<string>('');

  // Historical Glucose Logs (stored in state & localStorage)
  const [readings, setReadings] = useState<DiabetesReading[]>(() => {
    const saved = localStorage.getItem('diabetes_readings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    // Default initial historical readings for immediate demonstration
    return [
      { id: '1', timestamp: new Date(Date.now() - 86400000 * 2).toLocaleString(), type: 'fasting', glucoseMgDl: 96, notes: 'Fasting before breakfast. Felt energetic.' },
      { id: '2', timestamp: new Date(Date.now() - 86400000 * 2 + 7200000).toLocaleString(), type: 'post_meal', glucoseMgDl: 138, notes: '2 hours post oatmeal & chia seeds.' },
      { id: '3', timestamp: new Date(Date.now() - 86400000).toLocaleString(), type: 'fasting', glucoseMgDl: 102, notes: 'Morning check. Slightly elevated after late dinner.' },
      { id: '4', timestamp: new Date(Date.now() - 86400000 + 7200000).toLocaleString(), type: 'post_meal', glucoseMgDl: 128, notes: 'Post grilled chicken & lentil salad.' },
      { id: '5', timestamp: new Date().toLocaleString(), type: 'fasting', glucoseMgDl: 98, notes: 'Current baseline reading.' },
    ];
  });

  // AI Generated / Clinical Report Response
  const [reportResponse, setReportResponse] = useState<DiabetesReportResponse | null>(null);
  const [isLoadingReport, setIsLoadingReport] = useState<boolean>(false);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  // Save readings to localStorage
  useEffect(() => {
    localStorage.setItem('diabetes_readings', JSON.stringify(readings));
  }, [readings]);

  // Initial report generation on load if not fetched
  useEffect(() => {
    handleGenerateDiabetesReport();
  }, []);

  const handleAddReading = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLogGlucose || newLogGlucose <= 0) return;

    const newReading: DiabetesReading = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleString(),
      type: newLogType,
      glucoseMgDl: Number(newLogGlucose),
      notes: newLogNotes.trim() || undefined,
    };

    setReadings([newReading, ...readings]);
    
    // Update active input baseline if fasting or post meal
    if (newLogType === 'fasting') setFastingGlucose(Number(newLogGlucose));
    if (newLogType === 'post_meal') setPostMealGlucose(Number(newLogGlucose));

    setNewLogNotes('');
  };

  const handleDeleteReading = (id: string) => {
    setReadings(readings.filter(r => r.id !== id));
  };

  const handleGenerateDiabetesReport = async () => {
    setIsLoadingReport(true);
    try {
      const riskFactors: DiabetesRiskFactors = {
        fastingGlucoseMgDl: fastingGlucose,
        postMealGlucoseMgDl: postMealGlucose,
        hba1cPercent: hba1c,
        systolicBp,
        diastolicBp,
        familyHistory,
        highBpHistory,
        physicalInactivity,
      };

      const res = await fetch('/api/diabetes-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userProfile: {
            ...user,
            bmi: bmiMetrics.bmi,
          },
          riskFactors,
          readings,
        }),
      });

      const data = await res.json();
      if (res.ok && data) {
        setReportResponse(data);
      } else {
        throw new Error(data.error || 'Failed to fetch report');
      }
    } catch (err) {
      console.error('Error generating diabetes report:', err);
      // Fallback response structure
      setReportResponse({
        riskAssessment: {
          level: fastingGlucose >= 126 || hba1c >= 6.5 ? 'High Risk / Uncontrolled' : fastingGlucose >= 100 || hba1c >= 5.7 ? 'Pre-Diabetes / Borderline' : 'Low Risk',
          score: fastingGlucose >= 126 ? 8 : fastingGlucose >= 100 ? 5 : 2,
          summary: `Fasting Blood Glucose is ${fastingGlucose} mg/dL and HbA1c is ${hba1c}%. Maintaining low glycemic load meals with dietary fiber prevents insulin resistance.`
        },
        glycemicIndexGuideline: {
          maxCarbsPerMealG: 35,
          dailyFiberTargetG: 38,
          glycemicLoadCap: 'Low Glycemic Load (<10 per meal)'
        },
        clinicalAdvice: `### Clinical Diabetes & Glycemic Management Plan\n\n1. **Food Sequencing Strategy**: Eat non-starchy green vegetables and protein *before* complex carbohydrates to slow gastric emptying and lower glucose peaks.\n2. **10-Minute Post-Meal Walk**: Light activity right after lunch and dinner helps skeletal muscle absorb glucose without requiring excessive insulin secretion.\n3. **Hydration & Cinnamon**: Drinking 3L water daily aids renal glucose filtration. Incorporating 1/2 tsp cinnamon daily supports insulin receptor sensitivity.`,
        budgetLowGiFoods: [
          { food: 'Dried Green Lentils', giRating: 28, approxPrice: '$1.49 / lb', glycemicBenefit: 'Soluble fiber forms a gel matrix slowing carbohydrate absorption.' },
          { food: 'Fresh Whole Eggs', giRating: 0, approxPrice: '$2.99 / dozen', glycemicBenefit: 'Zero net carbs; provides choline and high bioavailability protein.' },
          { food: 'Chia Seeds', giRating: 1, approxPrice: '$3.99 / lb', glycemicBenefit: 'Prevents blood sugar spikes when mixed with oats or water.' },
          { food: 'Spinach & Dark Leafy Greens', giRating: 15, approxPrice: '$2.49 / bag', glycemicBenefit: 'High magnesium content supports cellular insulin response.' },
          { food: 'Canned Salmon / Sardines', giRating: 0, approxPrice: '$2.29 / can', glycemicBenefit: 'Anti-inflammatory omega-3 fatty acids reduce systemic metabolic stress.' }
        ],
        recommendedLowGiMeals: [
          { meal: 'Steel-Cut Oats with Chia & Cinnamon', description: 'Slow-cooked oats topped with 1 tbsp chia seeds, cinnamon, and walnuts', carbsG: 28, proteinG: 12, approxCost: '$1.60' },
          { meal: 'Lentil & Poached Egg Bowl', description: 'Warm seasoned lentils over spinach topped with a poached egg and olive oil', carbsG: 30, proteinG: 20, approxCost: '$2.20' },
          { meal: 'Grilled Salmon & Steamed Broccoli', description: 'Wild salmon fillet served with garlic broccoli and half avocado', carbsG: 6, proteinG: 32, approxCost: '$3.40' }
        ],
        warningFlags: [
          'If fasting glucose persistently exceeds 130 mg/dL, schedule an appointment with your endocrinologist or primary physician.',
          'Keep fast-acting glucose tablets or fruit juice available if on insulin or sulfonylureas to treat hypoglycemia.'
        ]
      });
    } finally {
      setIsLoadingReport(false);
    }
  };

  const getGlucoseStatus = (val: number, type: 'fasting' | 'post_meal' | 'random') => {
    if (type === 'fasting') {
      if (val < 100) return { label: 'Normal Fasting', color: 'bg-[#556b2f] text-[#fdfbf7]', border: 'border-[#556b2f]' };
      if (val <= 125) return { label: 'Pre-Diabetes Range', color: 'bg-[#8c826b] text-[#fdfbf7]', border: 'border-[#8c826b]' };
      return { label: 'High / Diabetic Range', color: 'bg-rose-700 text-white', border: 'border-rose-700' };
    } else {
      if (val < 140) return { label: 'Normal Post-Meal', color: 'bg-[#556b2f] text-[#fdfbf7]', border: 'border-[#556b2f]' };
      if (val <= 199) return { label: 'Elevated Post-Meal', color: 'bg-[#8c826b] text-[#fdfbf7]', border: 'border-[#8c826b]' };
      return { label: 'High Glucose Peak', color: 'bg-rose-700 text-white', border: 'border-rose-700' };
    }
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12 font-sans">
      
      {/* Hero Header Banner */}
      <div className="bg-[#334021] text-[#fdfbf7] rounded-3xl p-6 sm:p-8 border border-[#334021] shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#fdfbf7]/10 text-[#fdfbf7] text-xs font-bold border border-[#fdfbf7]/20">
              <Activity className="w-3.5 h-3.5 text-[#e5e0d1]" />
              <span>ADA-Aligned Clinical Glycemic Platform</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#fdfbf7]">
              Clinical Diabetes & Glycemic Health Report
            </h1>
            <p className="text-[#e5e0d1] text-xs sm:text-sm max-w-2xl leading-relaxed">
              Track fasting & post-prandial blood glucose, evaluate pre-diabetes risk metrics, receive AI endocrinological advice, and discover budget low-glycemic index meals.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleGenerateDiabetesReport}
              disabled={isLoadingReport}
              className="px-5 py-3 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold text-xs rounded-2xl shadow-sm transition-all flex items-center gap-2 cursor-pointer border border-[#e5e0d1]/30"
            >
              {isLoadingReport ? <RefreshCw className="w-4 h-4 animate-spin text-[#e5e0d1]" /> : <Sparkles className="w-4 h-4 text-[#e5e0d1]" />}
              <span>{isLoadingReport ? 'Analyzing...' : 'Recalculate AI Report'}</span>
            </button>

            <button
              onClick={() => setShowPrintModal(true)}
              className="px-4 py-3 bg-[#fdfbf7]/10 hover:bg-[#fdfbf7]/20 text-[#fdfbf7] font-bold text-xs rounded-2xl transition-colors flex items-center gap-2 cursor-pointer border border-[#fdfbf7]/20"
            >
              <Printer className="w-4 h-4 text-[#e5e0d1]" />
              <span>Print Medical Summary</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Inputs & Risk Assessor vs AI Clinical Report */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">

        {/* LEFT COLUMN: Blood Glucose Input & Risk Assessor (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Blood Glucose & Clinical Risk Input Card */}
          <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-5">
            <div className="flex items-center gap-3 border-b border-[#e5e0d1] pb-4">
              <div className="w-10 h-10 rounded-2xl bg-[#556b2f]/15 text-[#334021] flex items-center justify-center font-bold">
                <Droplets className="w-5 h-5 text-[#556b2f]" />
              </div>
              <div>
                <h2 className="font-serif text-base font-bold text-[#334021]">Blood Glucose & Risk Metrics</h2>
                <p className="text-[11px] text-[#8c826b]">ADA Standard Diagnostic Benchmarks</p>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#334021] mb-1">
                    Fasting Glucose (mg/dL)
                  </label>
                  <input
                    type="number"
                    value={fastingGlucose}
                    onChange={(e) => setFastingGlucose(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-bold focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                  <span className="text-[10px] text-[#8c826b] mt-1 block">
                    Normal: &lt;100 mg/dL
                  </span>
                </div>

                <div>
                  <label className="block font-bold text-[#334021] mb-1">
                    Post-Meal Glucose (mg/dL)
                  </label>
                  <input
                    type="number"
                    value={postMealGlucose}
                    onChange={(e) => setPostMealGlucose(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-bold focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                  <span className="text-[10px] text-[#8c826b] mt-1 block">
                    Normal: &lt;140 mg/dL
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#334021] mb-1">
                    HbA1c Level (%)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={hba1c}
                    onChange={(e) => setHba1c(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-bold focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                  <span className="text-[10px] text-[#8c826b] mt-1 block">
                    Normal: &lt;5.7%
                  </span>
                </div>

                <div>
                  <label className="block font-bold text-[#334021] mb-1">
                    Blood Pressure (mmHg)
                  </label>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      value={systolicBp}
                      onChange={(e) => setSystolicBp(Number(e.target.value))}
                      placeholder="Sys"
                      className="w-full px-2 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-bold text-center focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    />
                    <span className="font-bold text-[#8c826b]">/</span>
                    <input
                      type="number"
                      value={diastolicBp}
                      onChange={(e) => setDiastolicBp(Number(e.target.value))}
                      placeholder="Dia"
                      className="w-full px-2 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-bold text-center focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* ADA Risk Factor Toggles */}
              <div className="pt-2 border-t border-[#e5e0d1] space-y-2">
                <span className="text-[11px] font-bold text-[#334021] uppercase tracking-wider block">
                  ADA Diabetes Risk Assessment Checklist:
                </span>

                <label className="flex items-center gap-2 p-2.5 bg-[#e5e0d1]/20 rounded-xl border border-[#e5e0d1] cursor-pointer hover:bg-[#e5e0d1]/40 transition-colors">
                  <input
                    type="checkbox"
                    checked={familyHistory}
                    onChange={(e) => setFamilyHistory(e.target.checked)}
                    className="w-4 h-4 rounded text-[#556b2f] focus:ring-[#556b2f]"
                  />
                  <span className="text-xs font-medium text-[#334021]">Family History of Diabetes (Parent/Sibling)</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 bg-[#e5e0d1]/20 rounded-xl border border-[#e5e0d1] cursor-pointer hover:bg-[#e5e0d1]/40 transition-colors">
                  <input
                    type="checkbox"
                    checked={highBpHistory}
                    onChange={(e) => setHighBpHistory(e.target.checked)}
                    className="w-4 h-4 rounded text-[#556b2f] focus:ring-[#556b2f]"
                  />
                  <span className="text-xs font-medium text-[#334021]">History of High Blood Pressure (&gt;130/80)</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 bg-[#e5e0d1]/20 rounded-xl border border-[#e5e0d1] cursor-pointer hover:bg-[#e5e0d1]/40 transition-colors">
                  <input
                    type="checkbox"
                    checked={physicalInactivity}
                    onChange={(e) => setPhysicalInactivity(e.target.checked)}
                    className="w-4 h-4 rounded text-[#556b2f] focus:ring-[#556b2f]"
                  />
                  <span className="text-xs font-medium text-[#334021]">Physical Exercise Less Than 3 Times/Week</span>
                </label>
              </div>

              <button
                onClick={handleGenerateDiabetesReport}
                disabled={isLoadingReport}
                className="w-full py-3 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold rounded-xl shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                {isLoadingReport ? <RefreshCw className="w-4 h-4 animate-spin text-[#e5e0d1]" /> : <Sparkles className="w-4 h-4 text-[#e5e0d1]" />}
                <span>Generate Full Clinical Report</span>
              </button>
            </div>
          </div>

          {/* Log New Glucose Reading Box */}
          <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-[#e5e0d1] pb-3">
              <h3 className="font-serif text-sm font-bold text-[#334021] flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#556b2f]" />
                <span>Log New Blood Glucose Reading</span>
              </h3>
              <span className="text-[10px] text-[#8c826b] font-bold">Auto-Saved</span>
            </div>

            <form onSubmit={handleAddReading} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#334021] mb-1">Reading Type</label>
                  <select
                    value={newLogType}
                    onChange={(e) => setNewLogType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  >
                    <option value="fasting">Fasting (Morning)</option>
                    <option value="post_meal">Post-Meal (2 Hours)</option>
                    <option value="random">Random Spot Check</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[#334021] mb-1">Glucose Level (mg/dL)</label>
                  <input
                    type="number"
                    value={newLogGlucose}
                    onChange={(e) => setNewLogGlucose(Number(e.target.value))}
                    placeholder="e.g. 105"
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-bold focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#334021] mb-1">Notes / Meal Context</label>
                <input
                  type="text"
                  value={newLogNotes}
                  onChange={(e) => setNewLogNotes(e.target.value)}
                  placeholder="e.g. Ate lentil bowl 2 hours ago. Walked 15 mins."
                  className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#8c826b]/20 hover:bg-[#8c826b]/30 text-[#334021] font-bold rounded-xl border border-[#e5e0d1] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4 text-[#556b2f]" />
                <span>Save Reading to Glucose Log</span>
              </button>
            </form>
          </div>

        </div>

        {/* RIGHT COLUMN: AI Clinical Assessment Report & Low-GI Guidance (7 cols) */}
        <div className="lg:col-span-7 space-y-6">

          {/* AI Clinical Risk Assessment Card */}
          {isLoadingReport ? (
            <div className="p-12 text-center bg-[#fdfbf7] rounded-3xl border border-[#e5e0d1] space-y-3 shadow-sm">
              <div className="w-12 h-12 rounded-full bg-[#556b2f]/20 text-[#556b2f] mx-auto flex items-center justify-center animate-spin">
                <RefreshCw className="w-6 h-6 text-[#556b2f]" />
              </div>
              <p className="font-serif text-sm font-bold text-[#334021]">Evaluating Clinical Glycemic Profile...</p>
              <p className="text-xs text-[#8c826b]">Analyzing Fasting Glucose ({fastingGlucose} mg/dL), HbA1c ({hba1c}%), and low-GI budget nutrition strategy.</p>
            </div>
          ) : reportResponse ? (
            <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-6">
              
              {/* Report Header & Risk Level Badge */}
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#e5e0d1] pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-[#556b2f] text-[#fdfbf7] flex items-center justify-center font-bold">
                    👨‍⚕️
                  </div>
                  <div>
                    <h2 className="font-serif text-base font-bold text-[#334021]">Dr. Elena Vance Clinical Assessment</h2>
                    <p className="text-[11px] text-[#8c826b]">Endocrinological & Glycemic Specialist</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-xl text-xs font-bold border ${
                    reportResponse.riskAssessment.level === 'Low Risk' ? 'bg-[#556b2f] text-[#fdfbf7] border-[#556b2f]' :
                    reportResponse.riskAssessment.level === 'Pre-Diabetes / Borderline' ? 'bg-[#8c826b] text-[#fdfbf7] border-[#8c826b]' :
                    'bg-rose-700 text-white border-rose-700'
                  }`}>
                    {reportResponse.riskAssessment.level}
                  </span>
                  <span className="px-2.5 py-1 bg-[#e5e0d1]/40 text-[#334021] text-xs font-bold rounded-xl border border-[#e5e0d1]">
                    Risk Score: {reportResponse.riskAssessment.score}/10
                  </span>
                </div>
              </div>

              {/* Assessment Summary Box */}
              <div className="p-4 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1] text-xs leading-relaxed space-y-1.5">
                <span className="font-bold text-[#334021] block">Diagnostic Summary:</span>
                <p className="text-[#334021]">{reportResponse.riskAssessment.summary}</p>
              </div>

              {/* Glycemic Targets Bar */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3.5 bg-[#556b2f]/10 rounded-2xl border border-[#556b2f]/20 text-center">
                  <span className="text-[10px] font-bold text-[#556b2f] uppercase tracking-wider block">Max Net Carbs</span>
                  <span className="font-serif text-base font-bold text-[#334021]">{reportResponse.glycemicIndexGuideline.maxCarbsPerMealG}g</span>
                  <span className="text-[10px] text-[#8c826b] block">/ meal max</span>
                </div>

                <div className="p-3.5 bg-[#8c826b]/10 rounded-2xl border border-[#8c826b]/20 text-center">
                  <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">Daily Fiber Target</span>
                  <span className="font-serif text-base font-bold text-[#334021]">{reportResponse.glycemicIndexGuideline.dailyFiberTargetG}g</span>
                  <span className="text-[10px] text-[#8c826b] block">/ day soluble fiber</span>
                </div>

                <div className="p-3.5 bg-[#334021]/10 rounded-2xl border border-[#334021]/20 text-center">
                  <span className="text-[10px] font-bold text-[#334021] uppercase tracking-wider block">Glycemic Load</span>
                  <span className="text-xs font-bold text-[#334021] truncate block mt-1">{reportResponse.glycemicIndexGuideline.glycemicLoadCap}</span>
                </div>
              </div>

              {/* Detailed Clinical Advice Text */}
              <div className="prose text-xs leading-relaxed max-w-none bg-[#fdfbf7] p-5 rounded-2xl border border-[#e5e0d1] text-[#334021] whitespace-pre-wrap">
                {reportResponse.clinicalAdvice}
              </div>

              {/* Recommended Low-GI Meals for Diabetes */}
              {reportResponse.recommendedLowGiMeals && reportResponse.recommendedLowGiMeals.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-xs font-bold text-[#334021] uppercase tracking-wider flex items-center gap-1.5">
                    <Utensils className="w-4 h-4 text-[#556b2f]" />
                    <span>Low-Glycemic Budget Meal Recommendations</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {reportResponse.recommendedLowGiMeals.map((meal, idx) => (
                      <div key={idx} className="p-4 bg-[#e5e0d1]/20 rounded-2xl border border-[#e5e0d1] space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-serif text-xs font-bold text-[#334021]">{meal.meal}</span>
                          <span className="text-xs font-bold text-[#fdfbf7] bg-[#556b2f] px-2 py-0.5 rounded">
                            {meal.approxCost}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#8c826b] leading-normal">{meal.description}</p>
                        <div className="flex items-center gap-3 text-[10px] font-bold text-[#334021] pt-1">
                          <span>🥖 Carbs: {meal.carbsG}g</span>
                          <span>🥩 Protein: {meal.proteinG}g</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Warning & Safety Protocols */}
              {reportResponse.warningFlags && reportResponse.warningFlags.length > 0 && (
                <div className="p-4 bg-amber-500/10 border border-amber-600/30 rounded-2xl space-y-2 text-xs">
                  <h4 className="font-bold text-[#334021] flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                    <ShieldAlert className="w-4 h-4 text-amber-700" />
                    <span>Clinical Safety & Hypoglycemia Guidelines</span>
                  </h4>
                  <ul className="space-y-1 text-[#334021] text-[11px]">
                    {reportResponse.warningFlags.map((flag, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-amber-700 font-bold">•</span>
                        <span>{flag}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

            </div>
          ) : null}

          {/* Historical Blood Sugar Readings Table */}
          <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-[#e5e0d1] pb-3">
              <div>
                <h3 className="font-serif text-sm font-bold text-[#334021]">Recent Blood Glucose Readings Log</h3>
                <p className="text-[11px] text-[#8c826b]">History of logged glucose spot checks</p>
              </div>
              <span className="px-2.5 py-1 bg-[#556b2f]/10 text-[#556b2f] text-xs font-bold rounded-xl">
                {readings.length} Total Logs
              </span>
            </div>

            {readings.length === 0 ? (
              <p className="text-xs text-[#8c826b] text-center py-6">No glucose logs recorded yet. Use the form on the left to add your first check.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead>
                    <tr className="border-b border-[#e5e0d1] text-[#8c826b] font-bold text-[10px] uppercase tracking-wider">
                      <th className="pb-2">Date / Time</th>
                      <th className="pb-2">Type</th>
                      <th className="pb-2">Reading</th>
                      <th className="pb-2">Status</th>
                      <th className="pb-2">Notes</th>
                      <th className="pb-2 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#e5e0d1]">
                    {readings.map((r) => {
                      const status = getGlucoseStatus(r.glucoseMgDl, r.type);
                      return (
                        <tr key={r.id} className="hover:bg-[#e5e0d1]/20 transition-colors">
                          <td className="py-2.5 text-[#334021] font-medium text-[11px] whitespace-nowrap">
                            {r.timestamp}
                          </td>
                          <td className="py-2.5 text-[#334021] font-bold capitalize">
                            {r.type.replace('_', ' ')}
                          </td>
                          <td className="py-2.5 font-serif font-bold text-sm text-[#334021]">
                            {r.glucoseMgDl} <span className="font-sans text-[10px] font-normal text-[#8c826b]">mg/dL</span>
                          </td>
                          <td className="py-2.5">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${status.color}`}>
                              {status.label}
                            </span>
                          </td>
                          <td className="py-2.5 text-[#8c826b] text-[11px] max-w-[160px] truncate">
                            {r.notes || '—'}
                          </td>
                          <td className="py-2.5 text-right">
                            <button
                              onClick={() => handleDeleteReading(r.id)}
                              className="p-1 text-[#8c826b] hover:text-rose-600 transition-colors cursor-pointer"
                              title="Delete log"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Budget Low-GI Food Staples Cheat Sheet */}
      <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-4">
        <div className="flex items-center gap-3 border-b border-[#e5e0d1] pb-4">
          <div className="w-10 h-10 rounded-2xl bg-[#556b2f]/15 text-[#334021] flex items-center justify-center font-bold">
            <Apple className="w-5 h-5 text-[#556b2f]" />
          </div>
          <div>
            <h2 className="font-serif text-base font-bold text-[#334021]">Highest Yield Budget Low-GI Grocery Staples</h2>
            <p className="text-[11px] text-[#8c826b]">Under $3/serving foods that flatten post-meal blood sugar spikes</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { food: 'Dried Green / Brown Lentils', gi: 'GI 28 (Very Low)', price: '$1.49 / lb', desc: 'Soluble fiber creates a viscous gel matrix in the stomach that significantly slows glucose absorption.' },
            { food: 'Chia & Flax Seeds', gi: 'GI 1 (Near Zero)', price: '$3.99 / lb', desc: 'Packed with alpha-linolenic acid (ALA) and mucilage fiber that delays carbohydrate breakdown.' },
            { food: 'Fresh Whole Eggs', gi: 'GI 0 (Zero Carbs)', price: '$2.99 / dozen', desc: 'High bioavailability protein that stabilizes appetite and halts insulin release.' },
            { food: 'Dark Spinach & Kale', gi: 'GI 15 (Very Low)', price: '$2.49 / bag', desc: 'Abundant in cellular magnesium, which improves skeletal muscle insulin receptor sensitivity.' },
            { food: 'Canned Wild Salmon', gi: 'GI 0 (Zero Carbs)', price: '$2.29 / can', desc: 'Provides anti-inflammatory Omega-3 fatty acids and complete amino acids for vascular health.' },
            { food: 'Ground Ceylon Cinnamon', gi: 'GI 0', price: '$1.99 / bottle', desc: 'Mimics insulin activity and improves glucose transport across cell membranes.' },
          ].map((item, idx) => (
            <div key={idx} className="p-4 bg-[#e5e0d1]/20 rounded-2xl border border-[#e5e0d1] space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-serif text-xs font-bold text-[#334021]">{item.food}</span>
                <span className="text-[10px] font-bold text-[#fdfbf7] bg-[#556b2f] px-2 py-0.5 rounded">
                  {item.gi}
                </span>
              </div>
              <p className="text-[10px] font-bold text-[#334021] bg-[#8c826b]/20 px-2 py-0.5 rounded inline-block">
                💰 {item.price}
              </p>
              <p className="text-[11px] text-[#8c826b] leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Official Medical Summary Printable Modal */}
      {showPrintModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#fdfbf7] text-[#334021] rounded-3xl max-w-2xl w-full p-8 border border-[#e5e0d1] shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto font-sans">
            
            <div className="flex items-center justify-between border-b border-[#e5e0d1] pb-4">
              <div>
                <h2 className="font-serif text-xl font-bold text-[#334021]">Official Patient Glycemic Health Summary</h2>
                <p className="text-xs text-[#8c826b]">Clinical Medical Report for Physician Review</p>
              </div>

              <button
                onClick={() => setShowPrintModal(false)}
                className="px-3 py-1 bg-[#e5e0d1] hover:bg-[#e5e0d1]/80 text-[#334021] text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>

            <div id="printable-area" className="space-y-4 text-xs">
              <div className="p-4 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1] grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-[#8c826b] font-bold uppercase block">Patient Name</span>
                  <span className="font-bold text-[#334021]">{user?.name || 'Patient'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#8c826b] font-bold uppercase block">Age / Gender / BMI</span>
                  <span className="font-bold text-[#334021]">{user?.age} yrs • {user?.gender} • BMI {bmiMetrics.bmi}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#8c826b] font-bold uppercase block">Fasting Blood Glucose</span>
                  <span className="font-serif font-bold text-[#334021]">{fastingGlucose} mg/dL</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#8c826b] font-bold uppercase block">HbA1c Level</span>
                  <span className="font-serif font-bold text-[#334021]">{hba1c}%</span>
                </div>
              </div>

              <div className="p-4 bg-[#556b2f]/10 rounded-2xl border border-[#556b2f]/20 space-y-1">
                <span className="text-[10px] font-bold text-[#556b2f] uppercase block">ADA Diagnostic Classification</span>
                <span className="font-serif text-base font-bold text-[#334021]">{reportResponse?.riskAssessment.level || 'Low Risk'}</span>
                <p className="text-[11px] text-[#8c826b]">{reportResponse?.riskAssessment.summary}</p>
              </div>

              <div className="p-4 bg-[#fdfbf7] rounded-2xl border border-[#e5e0d1] space-y-2">
                <span className="font-bold text-[#334021] block text-[11px] uppercase tracking-wider">Clinical Nutrition Rules:</span>
                <ul className="list-disc pl-4 space-y-1 text-[#8c826b]">
                  <li>Cap carbohydrates per meal at {reportResponse?.glycemicIndexGuideline.maxCarbsPerMealG || 35}g net carbs.</li>
                  <li>Maintain daily fiber intake at {reportResponse?.glycemicIndexGuideline.dailyFiberTargetG || 38}g.</li>
                  <li>Perform a 10-15 minute gentle walk immediately following major meals.</li>
                </ul>
              </div>

              <div className="pt-4 border-t border-[#e5e0d1] flex items-center justify-between text-[10px] text-[#8c826b]">
                <span>Generated by Good Food, Good Life Glycemic Engine</span>
                <span>Date: {new Date().toLocaleDateString()}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#e5e0d1]">
              <button
                onClick={() => window.print()}
                className="px-5 py-2.5 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold text-xs rounded-xl shadow-sm transition-colors cursor-pointer flex items-center gap-2"
              >
                <Printer className="w-4 h-4 text-[#e5e0d1]" />
                <span>Print Report (PDF)</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
