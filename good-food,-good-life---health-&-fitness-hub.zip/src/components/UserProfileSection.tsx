import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { calculateBMIMetrics } from '../lib/bmi';
import { FitnessGoal, Gender, ActivityLevel, PriceLevel } from '../types';
import { 
  User, 
  Scale, 
  Ruler, 
  Activity, 
  Target, 
  Flame, 
  Droplet, 
  Award, 
  Edit3, 
  Check, 
  Sparkles, 
  MapPin, 
  ChevronRight,
  Zap,
  Info,
  DollarSign
} from 'lucide-react';

interface UserProfileSectionProps {
  onNavigateToCoach: () => void;
  onNavigateToStores: () => void;
  onNavigateToDiabetes?: () => void;
}

export const UserProfileSection: React.FC<UserProfileSectionProps> = ({
  onNavigateToCoach,
  onNavigateToStores,
  onNavigateToDiabetes,
}) => {
  const { user, updateProfile, detectCurrentGPSLocation } = useAuth();
  const [isEditing, setIsEditing] = useState(false);

  // Form edit states
  const [name, setName] = useState(user?.name || 'Alex Rivera');
  const [age, setAge] = useState(user?.age || 27);
  const [gender, setGender] = useState<Gender>(user?.gender || 'male');
  const [heightCm, setHeightCm] = useState(user?.heightCm || 178);
  const [weightKg, setWeightKg] = useState(user?.weightKg || 74);
  const [fitnessGoal, setFitnessGoal] = useState<FitnessGoal>(user?.fitnessGoal || 'muscle_building');
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>(user?.activityLevel || 'moderate');
  const [budgetPreference, setBudgetPreference] = useState<PriceLevel>(user?.budgetPreference || '$');
  const [city, setCity] = useState(user?.location?.city || 'New York, NY');

  // Calculate real-time BMI and health metrics
  const bmiMetrics = calculateBMIMetrics(
    user?.weightKg || weightKg,
    user?.heightCm || heightCm,
    user?.age || age,
    user?.gender || gender,
    user?.fitnessGoal || fitnessGoal,
    user?.activityLevel || activityLevel
  );

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      age: Number(age),
      gender,
      heightCm: Number(heightCm),
      weightKg: Number(weightKg),
      fitnessGoal,
      activityLevel,
      budgetPreference,
      location: {
        ...(user?.location || { address: 'Main Street', lat: 40.7128, lng: -74.0060 }),
        city,
      }
    });
    setIsEditing(false);
  };

  const goalLabels: Record<FitnessGoal, string> = {
    weight_loss: 'Weight Loss (Caloric Deficit)',
    weight_gain: 'Weight Gain (Healthy Surplus)',
    muscle_building: 'Muscle Building & Hypertrophy',
    stay_fit: 'Stay Fit & Body Recomposition',
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      
      {/* Top Welcome & Quick Action Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-[#334021] p-6 sm:p-8 text-[#fdfbf7] shadow-lg border border-[#334021]">
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-[#556b2f]/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#fdfbf7]/10 text-[#fdfbf7] text-xs font-bold border border-[#fdfbf7]/20">
              <Sparkles className="w-3.5 h-3.5 text-[#e5e0d1]" />
              <span>10-12 Year Senior Trainer Platform</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#fdfbf7]">
              Hello, {user?.name || 'Athlete'}! 👋
            </h1>
            <p className="text-[#e5e0d1] text-xs sm:text-sm max-w-xl leading-relaxed font-sans">
              Welcome to Good Food, Good Life. Your personalized fitness & nutrition engine is active. Let’s review your body metrics, macro distribution, and budget healthy store recommendations.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onNavigateToCoach}
              className="px-5 py-3 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold text-xs rounded-2xl shadow-md transition-all active:scale-95 flex items-center gap-2 cursor-pointer border border-[#8c826b]/30"
            >
              <Sparkles className="w-4 h-4 text-[#e5e0d1]" />
              <span>Get AI Trainer Meal Plan</span>
            </button>
            {onNavigateToDiabetes && (
              <button
                onClick={onNavigateToDiabetes}
                className="px-5 py-3 bg-[#556b2f]/80 hover:bg-[#556b2f] text-[#fdfbf7] border border-[#e5e0d1]/30 font-bold text-xs rounded-2xl transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Activity className="w-4 h-4 text-[#e5e0d1]" />
                <span>Diabetes Health Report</span>
              </button>
            )}
            <button
              onClick={onNavigateToStores}
              className="px-5 py-3 bg-[#8c826b]/20 hover:bg-[#8c826b]/30 text-[#fdfbf7] border border-[#e5e0d1]/30 font-bold text-xs rounded-2xl transition-colors flex items-center gap-2 cursor-pointer"
            >
              <MapPin className="w-4 h-4 text-[#e5e0d1]" />
              <span>Find Budget Stores</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: User Profile Editor & Interactive BMI Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">

        {/* LEFT COLUMN: Profile Card & Goal Configuration (4 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm relative">
            
            <div className="flex items-center justify-between border-b border-[#e5e0d1] pb-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#556b2f]/15 text-[#334021] flex items-center justify-center font-bold">
                  <User className="w-5 h-5 text-[#556b2f]" />
                </div>
                <div>
                  <h2 className="font-serif text-base font-bold text-[#334021]">User Profile</h2>
                  <p className="text-[11px] text-[#8c826b]">Personal Health Metrics</p>
                </div>
              </div>

              <button
                onClick={() => setIsEditing(!isEditing)}
                className="px-3 py-1.5 rounded-xl bg-[#e5e0d1]/40 hover:bg-[#e5e0d1]/70 text-[#334021] text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer border border-[#e5e0d1]"
              >
                {isEditing ? <Check className="w-3.5 h-3.5 text-[#556b2f]" /> : <Edit3 className="w-3.5 h-3.5 text-[#556b2f]" />}
                <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
              </button>
            </div>

            {isEditing ? (
              /* Editable Profile Form */
              <form onSubmit={handleSaveProfile} className="space-y-4 text-xs font-sans">
                <div>
                  <label className="block font-bold text-[#334021] mb-1">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-[#334021] mb-1">Age</label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-[#334021] mb-1">Gender</label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value as Gender)}
                      className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    >
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-[#334021] mb-1">Height (cm)</label>
                    <input
                      type="number"
                      value={heightCm}
                      onChange={(e) => setHeightCm(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-[#334021] mb-1">Weight (kg)</label>
                    <input
                      type="number"
                      value={weightKg}
                      onChange={(e) => setWeightKg(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-[#334021] mb-1">Fitness Goal</label>
                  <select
                    value={fitnessGoal}
                    onChange={(e) => setFitnessGoal(e.target.value as FitnessGoal)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  >
                    <option value="weight_loss">Weight Loss</option>
                    <option value="weight_gain">Weight Gain</option>
                    <option value="muscle_building">Muscle Building</option>
                    <option value="stay_fit">Stay Fit</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-[#334021] mb-1">Activity Level</label>
                    <select
                      value={activityLevel}
                      onChange={(e) => setActivityLevel(e.target.value as ActivityLevel)}
                      className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    >
                      <option value="sedentary">Sedentary (Office)</option>
                      <option value="light">Light (1-2 days/wk)</option>
                      <option value="moderate">Moderate (3-5 days/wk)</option>
                      <option value="active">Active (6-7 days/wk)</option>
                      <option value="very_active">Very Active (Athlete)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-[#334021] mb-1">Food Budget Tier</label>
                    <select
                      value={budgetPreference}
                      onChange={(e) => setBudgetPreference(e.target.value as PriceLevel)}
                      className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                    >
                      <option value="$">$ (Budget Friendly)</option>
                      <option value="$$">$$ (Moderate)</option>
                      <option value="$$$">$$$ (Premium)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-[#334021] mb-1">City / Region</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold rounded-xl shadow-sm transition-colors cursor-pointer"
                >
                  Save Profile & Recalculate BMI
                </button>
              </form>
            ) : (
              /* Display Profile Specs */
              <div className="space-y-4 font-sans">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3.5 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1]">
                    <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">Age & Gender</span>
                    <span className="text-sm font-bold text-[#334021] capitalize">{user?.age} yrs • {user?.gender}</span>
                  </div>
                  <div className="p-3.5 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1]">
                    <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">Location</span>
                    <span className="text-sm font-bold text-[#334021] truncate block">{user?.location?.city || 'New York, NY'}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3.5 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1]">
                    <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">Height</span>
                    <span className="text-sm font-bold text-[#334021]">{user?.heightCm} cm ({Math.floor((user?.heightCm || 178) / 30.48)}' {Math.round(((user?.heightCm || 178) / 2.54) % 12)}")</span>
                  </div>
                  <div className="p-3.5 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1]">
                    <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">Weight</span>
                    <span className="text-sm font-bold text-[#334021]">{user?.weightKg} kg ({Math.round((user?.weightKg || 74) * 2.205)} lbs)</span>
                  </div>
                </div>

                <div className="p-4 bg-[#556b2f]/10 rounded-2xl border border-[#556b2f]/20 space-y-1">
                  <span className="text-[10px] font-extrabold text-[#556b2f] uppercase tracking-wider block">Selected Fitness Goal</span>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-[#334021]">
                      {goalLabels[user?.fitnessGoal || 'stay_fit']}
                    </span>
                    <span className="px-2 py-0.5 bg-[#556b2f] text-[#fdfbf7] text-[10px] font-bold rounded-md uppercase">
                      Active
                    </span>
                  </div>
                </div>

                <div className="p-3.5 bg-[#8c826b]/10 rounded-2xl border border-[#8c826b]/20 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-[#8c826b]" />
                    <span className="font-bold text-[#334021]">Food Budget Tier</span>
                  </div>
                  <span className="font-bold text-[#334021] bg-[#e5e0d1] px-2.5 py-1 rounded-lg">
                    {user?.budgetPreference === '$' && '$ (Under $10/meal)'}
                    {user?.budgetPreference === '$$' && '$$ (Under $18/meal)'}
                    {user?.budgetPreference === '$$$' && '$$$ (Flexible)'}
                  </span>
                </div>
              </div>
            )}

          </div>

          {/* Hydration & Water Target Card */}
          <div className="bg-[#fdfbf7] rounded-3xl p-5 border border-[#e5e0d1] flex items-center justify-between shadow-sm">
            <div className="space-y-1">
              <span className="text-[10px] font-extrabold text-[#556b2f] uppercase tracking-wider flex items-center gap-1">
                <Droplet className="w-3.5 h-3.5 text-[#556b2f] fill-[#556b2f]" />
                Daily Water Hydration
              </span>
              <p className="font-serif text-xl font-bold text-[#334021]">
                {bmiMetrics.waterLiters} Liters <span className="font-sans text-xs font-semibold text-[#8c826b]">/ day</span>
              </p>
              <p className="text-[11px] font-medium text-[#8c826b]">
                Calculated for optimal cellular transport & metabolic recovery.
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-[#556b2f]/10 text-[#556b2f] flex items-center justify-center font-bold text-lg border border-[#556b2f]/20">
              💧
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Interactive BMI Gauge, Macro Breakdown & Senior Trainer Advice (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* BMI Gauge & Calculator Display */}
          <div className="bg-[#fdfbf7] rounded-3xl p-6 border border-[#e5e0d1] shadow-sm space-y-6">
            
            <div className="flex items-center justify-between border-b border-[#e5e0d1] pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#556b2f]/15 text-[#334021] flex items-center justify-center font-bold">
                  <Scale className="w-5 h-5 text-[#556b2f]" />
                </div>
                <div>
                  <h2 className="font-serif text-base font-bold text-[#334021]">BMI Calculator & Health Gauge</h2>
                  <p className="text-[11px] text-[#8c826b]">Body Mass Index Analysis</p>
                </div>
              </div>

              <span className={`px-3 py-1 rounded-xl text-xs font-bold border ${bmiMetrics.color}`}>
                {bmiMetrics.category}
              </span>
            </div>

            {/* BMI Big Number & Gauge Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center bg-[#e5e0d1]/30 p-5 rounded-2xl border border-[#e5e0d1]">
              <div className="text-center md:border-r md:border-[#e5e0d1] pr-2">
                <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">Your BMI Score</span>
                <span className="font-serif text-4xl font-bold text-[#334021] tracking-tight">
                  {bmiMetrics.bmi}
                </span>
                <span className="text-[11px] font-bold text-[#8c826b] block mt-0.5">
                  kg / m²
                </span>
              </div>

              <div className="md:col-span-2 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-[#8c826b]">Ideal Weight Range</span>
                  <span className="text-[#556b2f] font-bold">
                    {bmiMetrics.idealWeightMinKg} kg – {bmiMetrics.idealWeightMaxKg} kg
                  </span>
                </div>

                {/* Multi-segment BMI Gauge Bar */}
                <div className="relative pt-2">
                  <div className="h-3 w-full rounded-full bg-[#e5e0d1] flex overflow-hidden">
                    <div className="h-full w-[18.5%] bg-[#8c826b]/50" title="Underweight (<18.5)"></div>
                    <div className="h-full w-[35%] bg-[#556b2f]" title="Normal (18.5 - 24.9)"></div>
                    <div className="h-full w-[25%] bg-[#8c826b]" title="Overweight (25 - 29.9)"></div>
                    <div className="h-full w-[21.5%] bg-[#334021]" title="Obese (30+)"></div>
                  </div>

                  {/* Marker Pin for current BMI */}
                  <div 
                    className="absolute top-0 transition-all duration-500 transform -translate-x-1/2"
                    style={{ left: `${Math.min(95, Math.max(5, (bmiMetrics.bmi / 40) * 100))}%` }}
                  >
                    <div className="w-3 h-3 bg-[#334021] rotate-45 border-2 border-[#fdfbf7] shadow-md"></div>
                  </div>
                </div>

                <div className="flex justify-between text-[10px] font-semibold text-[#8c826b] pt-1">
                  <span>15</span>
                  <span>18.5 (Normal)</span>
                  <span>25 (Overweight)</span>
                  <span>30+ (Obese)</span>
                </div>
              </div>
            </div>

            {/* Daily Energy & Target Calories */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3.5 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1] text-center">
                <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">BMR (Basal Rate)</span>
                <span className="text-base font-bold text-[#334021]">{bmiMetrics.bmr}</span>
                <span className="text-[10px] text-[#8c826b] block">kcal/day</span>
              </div>
              <div className="p-3.5 bg-[#e5e0d1]/30 rounded-2xl border border-[#e5e0d1] text-center">
                <span className="text-[10px] font-bold text-[#8c826b] uppercase tracking-wider block">TDEE (Burn)</span>
                <span className="text-base font-bold text-[#334021]">{bmiMetrics.tdee}</span>
                <span className="text-[10px] text-[#8c826b] block">kcal/day</span>
              </div>
              <div className="p-3.5 bg-[#556b2f]/10 rounded-2xl border border-[#556b2f]/30 text-center">
                <span className="text-[10px] font-bold text-[#556b2f] uppercase tracking-wider block">Target Calories</span>
                <span className="text-base font-bold text-[#334021]">{bmiMetrics.targetCalories}</span>
                <span className="text-[10px] text-[#556b2f] block">kcal/day</span>
              </div>
            </div>

            {/* Target Macros Distribution */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold text-[#334021] uppercase tracking-wider flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-[#556b2f]" />
                <span>Daily Target Macros ({user?.fitnessGoal?.replace('_', ' ')})</span>
              </h3>

              <div className="grid grid-cols-3 gap-3">
                {/* Protein */}
                <div className="p-3.5 bg-[#556b2f]/10 rounded-2xl border border-[#556b2f]/20">
                  <div className="flex items-center justify-between text-xs font-bold text-[#334021] mb-1">
                    <span>Protein</span>
                    <span className="font-bold text-[#334021]">{bmiMetrics.proteinG}g</span>
                  </div>
                  <div className="h-2 bg-[#e5e0d1] rounded-full overflow-hidden">
                    <div className="h-full bg-[#556b2f] w-full"></div>
                  </div>
                  <span className="text-[10px] text-[#8c826b] font-medium block mt-1">
                    {bmiMetrics.proteinG * 4} kcal ({Math.round((bmiMetrics.proteinG * 4 / bmiMetrics.targetCalories) * 100)}%)
                  </span>
                </div>

                {/* Carbs */}
                <div className="p-3.5 bg-[#8c826b]/10 rounded-2xl border border-[#8c826b]/20">
                  <div className="flex items-center justify-between text-xs font-bold text-[#334021] mb-1">
                    <span>Carbs</span>
                    <span className="font-bold text-[#334021]">{bmiMetrics.carbsG}g</span>
                  </div>
                  <div className="h-2 bg-[#e5e0d1] rounded-full overflow-hidden">
                    <div className="h-full bg-[#8c826b] w-[85%]"></div>
                  </div>
                  <span className="text-[10px] text-[#8c826b] font-medium block mt-1">
                    {bmiMetrics.carbsG * 4} kcal ({Math.round((bmiMetrics.carbsG * 4 / bmiMetrics.targetCalories) * 100)}%)
                  </span>
                </div>

                {/* Fats */}
                <div className="p-3.5 bg-[#334021]/10 rounded-2xl border border-[#334021]/20">
                  <div className="flex items-center justify-between text-xs font-bold text-[#334021] mb-1">
                    <span>Healthy Fat</span>
                    <span className="font-bold text-[#334021]">{bmiMetrics.fatG}g</span>
                  </div>
                  <div className="h-2 bg-[#e5e0d1] rounded-full overflow-hidden">
                    <div className="h-full bg-[#334021] w-[60%]"></div>
                  </div>
                  <span className="text-[10px] text-[#8c826b] font-medium block mt-1">
                    {bmiMetrics.fatG * 9} kcal ({Math.round((bmiMetrics.fatG * 9 / bmiMetrics.targetCalories) * 100)}%)
                  </span>
                </div>
              </div>
            </div>

          </div>

          {/* 10-12 Year Senior Trainer Clinical Assessment Card */}
          <div className="bg-[#334021] text-[#fdfbf7] rounded-3xl p-6 border border-[#334021] shadow-lg space-y-4 relative overflow-hidden">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#fdfbf7]/10 text-[#fdfbf7] border border-[#fdfbf7]/20 flex items-center justify-center font-black text-xl">
                  👨‍⚕️
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif text-base font-bold text-[#fdfbf7]">Coach Marcus Vance</h3>
                    <span className="px-2 py-0.5 bg-[#fdfbf7]/15 text-[#e5e0d1] text-[10px] font-bold rounded-md uppercase border border-[#fdfbf7]/20">
                      12 Yrs Exp
                    </span>
                  </div>
                  <p className="text-[11px] text-[#e5e0d1] font-medium">Senior Clinical Fitness & Nutrition Trainer</p>
                </div>
              </div>

              <button
                onClick={onNavigateToCoach}
                className="px-3.5 py-1.5 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] text-xs font-bold rounded-xl shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer border border-[#e5e0d1]/30"
              >
                <span>Ask Coach AI</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#e5e0d1]" />
              </button>
            </div>

            <div className="bg-[#fdfbf7]/10 rounded-2xl p-4 border border-[#fdfbf7]/15 text-[#e5e0d1] text-xs leading-relaxed space-y-2 font-sans">
              <p className="font-semibold text-[#fdfbf7]">
                {bmiMetrics.trainerNote}
              </p>
              <p className="text-[11px] text-[#e5e0d1]">
                💡 <strong>Budget Tip:</strong> Source clean proteins like eggs, Greek yogurt, canned salmon, and lentils at under $1.50 per serving. Combine with local $8 salad bars or juice shop protein blends.
              </p>
            </div>

            <div className="flex items-center justify-between text-[11px] font-semibold text-[#e5e0d1] pt-1">
              <span>✓ Verified Clinical Macro Ratio</span>
              <span>✓ Hydration Target: {bmiMetrics.waterLiters}L/day</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
