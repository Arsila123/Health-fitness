import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Heart, 
  MapPin, 
  User, 
  Sparkles, 
  BookOpen, 
  Compass, 
  LogIn, 
  LogOut, 
  Navigation,
  UtensilsCrossed,
  SlidersHorizontal,
  ChevronDown,
  Activity
} from 'lucide-react';

interface NavbarProps {
  activeTab: 'dashboard' | 'stores' | 'coach' | 'guide' | 'diabetes';
  setActiveTab: (tab: 'dashboard' | 'stores' | 'coach' | 'guide' | 'diabetes') => void;
  onOpenAuthModal: (mode: 'login' | 'signup' | 'forgot') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAuthModal,
}) => {
  const { user, isAuthenticated, logout, detectCurrentGPSLocation } = useAuth();
  const [isLocating, setIsLocating] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const handleDetectLocation = async () => {
    setIsLocating(true);
    await detectCurrentGPSLocation();
    setIsLocating(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Brand Logo */}
          <div 
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-amber-500 p-0.5 shadow-sm group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-white rounded-[10px] flex items-center justify-center">
                <UtensilsCrossed className="w-5 h-5 text-emerald-600" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-stone-900">
                  Good Food
                </span>
                <span className="text-emerald-600 font-extrabold text-xl">,</span>
                <span className="font-extrabold text-xl tracking-tight text-emerald-600">
                  Good Life
                </span>
              </div>
              <p className="text-[11px] font-medium text-stone-500 -mt-1 tracking-wider uppercase">
                NutriFit & Budget Food Finder
              </p>
            </div>
          </div>

          {/* Navigation Items (Desktop) */}
          <nav className="hidden md:flex items-center gap-1.5 bg-stone-100/80 p-1.5 rounded-2xl border border-stone-200/60">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'dashboard'
                  ? 'bg-white text-emerald-700 shadow-xs border border-stone-200/80'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
              }`}
            >
              <User className="w-4 h-4 text-emerald-600" />
              <span>Dashboard & BMI</span>
            </button>

            <button
              onClick={() => setActiveTab('stores')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'stores'
                  ? 'bg-white text-emerald-700 shadow-xs border border-stone-200/80'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
              }`}
            >
              <Compass className="w-4 h-4 text-amber-500" />
              <span>Healthy Stores Map</span>
              <span className="px-1.5 py-0.5 text-[10px] bg-amber-100 text-amber-800 rounded-md font-bold uppercase tracking-wider">
                Budget
              </span>
            </button>

            <button
              onClick={() => setActiveTab('coach')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'coach'
                  ? 'bg-[#556b2f] text-[#fdfbf7] shadow-xs border border-[#556b2f]'
                  : 'text-[#334021] hover:text-[#334021] hover:bg-[#e5e0d1]/50'
              }`}
            >
              <Sparkles className="w-4 h-4 text-[#556b2f] group-hover:text-[#334021]" />
              <span>AI Coach</span>
            </button>

            <button
              onClick={() => setActiveTab('diabetes')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'diabetes'
                  ? 'bg-[#556b2f] text-[#fdfbf7] shadow-xs border border-[#556b2f]'
                  : 'text-[#334021] hover:text-[#334021] hover:bg-[#e5e0d1]/50'
              }`}
            >
              <Activity className="w-4 h-4 text-[#556b2f]" />
              <span>Diabetes Report</span>
            </button>

            <button
              onClick={() => setActiveTab('guide')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'guide'
                  ? 'bg-[#556b2f] text-[#fdfbf7] shadow-xs border border-[#556b2f]'
                  : 'text-[#334021] hover:text-[#334021] hover:bg-[#e5e0d1]/50'
              }`}
            >
              <BookOpen className="w-4 h-4 text-[#556b2f]" />
              <span>Nutrition Guide</span>
            </button>
          </nav>

          {/* Right Action Section: Location Pill & User Menu */}
          <div className="flex items-center gap-3">
            {/* GPS Location pill */}
            <button
              onClick={handleDetectLocation}
              disabled={isLocating}
              title="Click to detect current location via GPS"
              className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-medium hover:bg-emerald-100/70 transition-colors"
            >
              <MapPin className={`w-3.5 h-3.5 text-emerald-600 ${isLocating ? 'animate-bounce' : ''}`} />
              <span className="max-w-[140px] truncate">
                {user?.location?.city || 'Detect Location'}
              </span>
              <Navigation className="w-3 h-3 text-emerald-500 ml-0.5" />
            </button>

            {/* Auth / Profile Dropdown */}
            {isAuthenticated && user ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2.5 p-1.5 pr-3 rounded-2xl border border-stone-200 bg-stone-50 hover:bg-stone-100 transition-colors"
                >
                  <img
                    src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
                    alt={user.name}
                    className="w-8 h-8 rounded-xl object-cover ring-2 ring-emerald-500/20"
                  />
                  <div className="text-left hidden sm:block">
                    <p className="text-xs font-bold text-stone-900 leading-tight">
                      {user.name}
                    </p>
                    <p className="text-[10px] text-emerald-600 font-semibold uppercase tracking-wider">
                      {user.fitnessGoal.replace('_', ' ')}
                    </p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-400 ml-1" />
                </button>

                {showUserDropdown && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-stone-200 py-2 z-50">
                    <div className="px-4 py-2 border-b border-stone-100">
                      <p className="text-xs font-bold text-stone-900">{user.name}</p>
                      <p className="text-[11px] text-stone-500 truncate">{user.email}</p>
                      <div className="mt-1 flex items-center gap-2 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md inline-block">
                        Goal: {user.fitnessGoal.toUpperCase().replace('_', ' ')}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setActiveTab('dashboard');
                        setShowUserDropdown(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-stone-700 hover:bg-stone-50 flex items-center gap-2"
                    >
                      <User className="w-3.5 h-3.5 text-stone-500" />
                      View Profile & BMI
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('stores');
                        setShowUserDropdown(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-stone-700 hover:bg-stone-50 flex items-center gap-2"
                    >
                      <Compass className="w-3.5 h-3.5 text-stone-500" />
                      Find Nearby Salad & Juice Bars
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('diabetes');
                        setShowUserDropdown(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-stone-700 hover:bg-stone-50 flex items-center gap-2"
                    >
                      <Activity className="w-3.5 h-3.5 text-[#556b2f]" />
                      Clinical Diabetes Report
                    </button>

                    <div className="border-t border-stone-100 my-1"></div>

                    <button
                      onClick={() => {
                        logout();
                        setShowUserDropdown(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-500" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenAuthModal('login')}
                  className="px-4 py-2 text-xs font-bold text-stone-700 hover:text-stone-900 transition-colors"
                >
                  Sign In
                </button>
                <button
                  onClick={() => onOpenAuthModal('signup')}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors"
                >
                  Sign Up
                </button>
              </div>
            )}

          </div>

        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex items-center justify-around border-t border-stone-100 py-2.5">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center gap-1 text-[11px] font-medium ${
              activeTab === 'dashboard' ? 'text-emerald-600 font-bold' : 'text-stone-500'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Profile</span>
          </button>

          <button
            onClick={() => setActiveTab('stores')}
            className={`flex flex-col items-center gap-1 text-[11px] font-medium ${
              activeTab === 'stores' ? 'text-emerald-600 font-bold' : 'text-stone-500'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Map Stores</span>
          </button>

          <button
            onClick={() => setActiveTab('coach')}
            className={`flex flex-col items-center gap-1 text-[11px] font-medium ${
              activeTab === 'coach' ? 'text-[#556b2f] font-bold' : 'text-stone-500'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Coach</span>
          </button>

          <button
            onClick={() => setActiveTab('diabetes')}
            className={`flex flex-col items-center gap-1 text-[11px] font-medium ${
              activeTab === 'diabetes' ? 'text-[#556b2f] font-bold' : 'text-stone-500'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Diabetes</span>
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`flex flex-col items-center gap-1 text-[11px] font-medium ${
              activeTab === 'guide' ? 'text-[#556b2f] font-bold' : 'text-stone-500'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Guide</span>
          </button>
        </div>

      </div>
    </header>
  );
};
