import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { FitnessGoal, Gender, PriceLevel } from '../types';
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  MapPin, 
  Sparkles, 
  Target, 
  DollarSign, 
  Scale, 
  Ruler, 
  ArrowRight, 
  CheckCircle2,
  Navigation
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'login' | 'signup' | 'forgot';
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'login',
  onClose,
}) => {
  const { login, signUp, googleLogin, forgotPassword, detectCurrentGPSLocation } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>(initialMode);

  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');

  // Sign Up state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [age, setAge] = useState<number>(26);
  const [gender, setGender] = useState<Gender>('male');
  const [heightCm, setHeightCm] = useState<number>(175);
  const [weightKg, setWeightKg] = useState<number>(70);
  const [fitnessGoal, setFitnessGoal] = useState<FitnessGoal>('stay_fit');
  const [budgetPreference, setBudgetPreference] = useState<PriceLevel>('$');
  const [locationCity, setLocationCity] = useState('New York, NY');
  const [locationAddress, setLocationAddress] = useState('Central District');

  // Forgot password
  const [forgotEmail, setForgotEmail] = useState('');

  // Status & Feedback
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage(null);
    const res = await login(loginEmail, loginPass);
    setIsSubmitting(false);
    if (res.success) {
      setMessage({ type: 'success', text: res.message || 'Logged in!' });
      setTimeout(() => {
        onClose();
      }, 600);
    } else {
      setMessage({ type: 'error', text: res.message || 'Login failed.' });
    }
  };

  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage(null);
    const res = await signUp({
      name,
      email,
      age: Number(age),
      gender,
      heightCm: Number(heightCm),
      weightKg: Number(weightKg),
      fitnessGoal,
      budgetPreference,
      location: {
        address: locationAddress,
        city: locationCity,
        lat: 40.7128,
        lng: -74.0060,
      }
    });
    setIsSubmitting(false);
    if (res.success) {
      setMessage({ type: 'success', text: 'Welcome to Good Food, Good Life!' });
      setTimeout(() => {
        onClose();
      }, 700);
    } else {
      setMessage({ type: 'error', text: res.message || 'Sign up failed.' });
    }
  };

  const handleGoogleSubmit = async () => {
    setIsSubmitting(true);
    const res = await googleLogin();
    setIsSubmitting(false);
    if (res.success) {
      onClose();
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage(null);
    const res = await forgotPassword(forgotEmail);
    setIsSubmitting(false);
    setMessage({ type: res.success ? 'success' : 'error', text: res.message || '' });
  };

  const handleDetectGPSInModal = async () => {
    const res = await detectCurrentGPSLocation();
    if (res.success) {
      setLocationAddress('Current GPS Coordinates');
      setLocationCity(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#334021]/60 backdrop-blur-xs animate-fade-in font-sans">
      <div className="relative w-full max-w-lg bg-[#fdfbf7] rounded-3xl shadow-2xl border border-[#e5e0d1] overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-5 bg-[#334021] text-[#fdfbf7] flex items-center justify-between border-b border-[#334021]">
          <div>
            <span className="text-xs font-bold text-[#e5e0d1] uppercase tracking-widest">
              NutriFit Community
            </span>
            <h2 className="font-serif text-xl font-bold text-[#fdfbf7]">
              {mode === 'login' && 'Sign In to Your Hub'}
              {mode === 'signup' && 'Create Your Fitness Profile'}
              {mode === 'forgot' && 'Reset Your Password'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#e5e0d1] hover:text-white rounded-full bg-[#fdfbf7]/10 hover:bg-[#fdfbf7]/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-[#e5e0d1] bg-[#e5e0d1]/30">
          <button
            onClick={() => { setMode('login'); setMessage(null); }}
            className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              mode === 'login'
                ? 'border-[#556b2f] text-[#334021] bg-[#fdfbf7]'
                : 'border-transparent text-[#8c826b] hover:text-[#334021]'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => { setMode('signup'); setMessage(null); }}
            className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              mode === 'signup'
                ? 'border-[#556b2f] text-[#334021] bg-[#fdfbf7]'
                : 'border-transparent text-[#8c826b] hover:text-[#334021]'
            }`}
          >
            Sign Up
          </button>
          <button
            onClick={() => { setMode('forgot'); setMessage(null); }}
            className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              mode === 'forgot'
                ? 'border-[#556b2f] text-[#334021] bg-[#fdfbf7]'
                : 'border-transparent text-[#8c826b] hover:text-[#334021]'
            }`}
          >
            Forgot Password
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto space-y-4 bg-[#fdfbf7]">

          {message && (
            <div className={`p-3.5 rounded-2xl text-xs font-semibold flex items-center gap-2 ${
              message.type === 'success' 
                ? 'bg-[#556b2f]/15 text-[#334021] border border-[#556b2f]/30'
                : 'bg-rose-50 text-rose-900 border border-rose-200'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0 text-[#556b2f]" />
              <span>{message.text}</span>
            </div>
          )}

          {/* SIGN IN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#334021] mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8c826b] absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="alex@example.com"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#334021]">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-[11px] font-semibold text-[#556b2f] hover:underline cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-[#8c826b] absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={loginPass}
                    onChange={(e) => setLoginPass(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold text-xs rounded-xl shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Sign In</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="relative my-4 text-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-[#e5e0d1]"></div>
                </div>
                <span className="relative px-3 bg-[#fdfbf7] text-[11px] font-semibold text-[#8c826b]">
                  OR QUICK ACCESS
                </span>
              </div>

              {/* Demo Fast Login */}
              <button
                type="button"
                onClick={() => {
                  setLoginEmail('alex.rivera@example.com');
                  setLoginPass('password123');
                  login('alex.rivera@example.com', 'password123');
                  onClose();
                }}
                className="w-full py-2.5 bg-[#8c826b]/15 hover:bg-[#8c826b]/25 text-[#334021] border border-[#8c826b]/30 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#556b2f]" />
                <span>One-Click Demo Account Login</span>
              </button>

              {/* Google Option */}
              <button
                type="button"
                onClick={handleGoogleSubmit}
                className="w-full py-2.5 bg-[#fdfbf7] hover:bg-[#e5e0d1]/30 text-[#334021] border border-[#e5e0d1] font-semibold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>Continue with Google</span>
              </button>
            </form>
          )}

          {/* SIGN UP FORM */}
          {mode === 'signup' && (
            <form onSubmit={handleSignUpSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#334021] mb-1">Name</label>
                  <input
                    type="text"
                    required
                    placeholder="John Doe"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#334021] mb-1">Email</label>
                  <input
                    type="email"
                    required
                    placeholder="john@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#334021] mb-1">Age</label>
                  <input
                    type="number"
                    required
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#334021] mb-1">Gender</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as Gender)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#334021] mb-1">Budget</label>
                  <select
                    value={budgetPreference}
                    onChange={(e) => setBudgetPreference(e.target.value as PriceLevel)}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  >
                    <option value="$">$ (Budget Friendly)</option>
                    <option value="$$">$$ (Moderate)</option>
                    <option value="$$$">$$$ (Premium)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#334021] mb-1">Height (cm)</label>
                  <input
                    type="number"
                    required
                    value={heightCm}
                    onChange={(e) => setHeightCm(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#334021] mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    required
                    value={weightKg}
                    onChange={(e) => setWeightKg(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334021] mb-1">Fitness Goal</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'weight_loss', label: 'Weight Loss' },
                    { id: 'weight_gain', label: 'Weight Gain' },
                    { id: 'muscle_building', label: 'Muscle Building' },
                    { id: 'stay_fit', label: 'Stay Fit & Healthy' },
                  ].map((g) => (
                    <button
                      type="button"
                      key={g.id}
                      onClick={() => setFitnessGoal(g.id as FitnessGoal)}
                      className={`p-2 rounded-xl text-xs font-bold border text-left transition-all cursor-pointer ${
                        fitnessGoal === g.id
                          ? 'bg-[#556b2f]/15 border-[#556b2f] text-[#334021]'
                          : 'bg-[#e5e0d1]/30 border-[#e5e0d1] text-[#8c826b] hover:bg-[#e5e0d1]/50'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#334021]">Your Location</label>
                  <button
                    type="button"
                    onClick={handleDetectGPSInModal}
                    className="text-[11px] font-semibold text-[#556b2f] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Navigation className="w-3 h-3" />
                    Detect GPS
                  </button>
                </div>
                <input
                  type="text"
                  required
                  placeholder="City, State or Address"
                  value={locationCity}
                  onChange={(e) => setLocationCity(e.target.value)}
                  className="w-full px-3 py-2 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#556b2f] hover:bg-[#435524] text-[#fdfbf7] font-bold text-xs rounded-xl shadow-sm transition-colors cursor-pointer"
              >
                Create Account & Calculate BMI
              </button>
            </form>
          )}

          {/* FORGOT PASSWORD FORM */}
          {mode === 'forgot' && (
            <form onSubmit={handleForgotSubmit} className="space-y-4 py-2">
              <p className="text-xs text-[#8c826b] leading-relaxed">
                Enter your registered email address below. We'll send you a password reset link along with security instructions.
              </p>

              <div>
                <label className="block text-xs font-bold text-[#334021] mb-1">
                  Registered Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8c826b] absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="alex@example.com"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-[#fdfbf7] border border-[#e5e0d1] text-[#334021] rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#556b2f] focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#334021] hover:bg-[#252f18] text-[#fdfbf7] font-bold text-xs rounded-xl shadow-sm transition-colors cursor-pointer"
              >
                Send Password Reset Email
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
