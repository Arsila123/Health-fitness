import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserLocation, FitnessGoal, Gender, ActivityLevel, PriceLevel } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  signUp: (data: Partial<UserProfile>) => Promise<{ success: boolean; message?: string }>;
  googleLogin: () => Promise<{ success: boolean; message?: string }>;
  forgotPassword: (email: string) => Promise<{ success: boolean; message?: string }>;
  updateProfile: (updatedData: Partial<UserProfile>) => void;
  updateLocation: (loc: UserLocation) => void;
  detectCurrentGPSLocation: () => Promise<{ success: boolean; message: string }>;
  logout: () => void;
}

const DEFAULT_PROFILE: UserProfile = {
  id: 'usr-default-01',
  name: 'Alex Rivera',
  email: 'alex.rivera@example.com',
  age: 27,
  gender: 'male',
  heightCm: 178,
  weightKg: 74,
  fitnessGoal: 'muscle_building',
  activityLevel: 'moderate',
  location: {
    address: '100 Broadway Ave',
    city: 'New York, NY',
    lat: 40.7128,
    lng: -74.0060,
  },
  dietaryPreference: 'high_protein',
  budgetPreference: '$',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  createdAt: new Date().toISOString(),
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Load from localStorage or initialize with default profile for seamless experience
    try {
      const savedUser = localStorage.getItem('goodlife_user_profile');
      if (savedUser) {
        setUser(JSON.parse(savedUser));
        setIsAuthenticated(true);
      } else {
        // Initialize default user so visitor can immediately explore BMI and Store Finder
        setUser(DEFAULT_PROFILE);
        setIsAuthenticated(true);
        localStorage.setItem('goodlife_user_profile', JSON.stringify(DEFAULT_PROFILE));
      }
    } catch (e) {
      console.error('Failed to parse saved user:', e);
      setUser(DEFAULT_PROFILE);
      setIsAuthenticated(true);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const saveUserToStateAndStorage = (newProfile: UserProfile) => {
    setUser(newProfile);
    setIsAuthenticated(true);
    localStorage.setItem('goodlife_user_profile', JSON.stringify(newProfile));
  };

  const login = async (email: string, pass: string) => {
    if (!email || !pass) {
      return { success: false, message: 'Please enter your email and password.' };
    }
    // Simulate auth check
    const existing = user || DEFAULT_PROFILE;
    const updated: UserProfile = {
      ...existing,
      email,
      name: email.split('@')[0].replace('.', ' ').toUpperCase() || existing.name,
    };
    saveUserToStateAndStorage(updated);
    return { success: true, message: 'Welcome back to Good Food, Good Life!' };
  };

  const signUp = async (data: Partial<UserProfile>) => {
    if (!data.name || !data.email) {
      return { success: false, message: 'Name and Email are required.' };
    }

    const newProfile: UserProfile = {
      id: `usr-${Date.now()}`,
      name: data.name,
      email: data.email,
      age: Number(data.age) || 26,
      gender: (data.gender as Gender) || 'male',
      heightCm: Number(data.heightCm) || 172,
      weightKg: Number(data.weightKg) || 68,
      fitnessGoal: (data.fitnessGoal as FitnessGoal) || 'stay_fit',
      activityLevel: (data.activityLevel as ActivityLevel) || 'moderate',
      location: data.location || {
        address: 'Downtown City Center',
        city: 'New York, NY',
        lat: 40.7128,
        lng: -74.0060,
      },
      dietaryPreference: data.dietaryPreference || 'all',
      budgetPreference: (data.budgetPreference as PriceLevel) || '$',
      avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(data.name)}`,
      createdAt: new Date().toISOString(),
    };

    saveUserToStateAndStorage(newProfile);
    return { success: true, message: 'Account created successfully!' };
  };

  const googleLogin = async () => {
    // Simulated Google OAuth login flow
    const googleUser: UserProfile = {
      ...DEFAULT_PROFILE,
      id: `usr-google-${Date.now()}`,
      name: 'Google User',
      email: 'google.fitness@gmail.com',
      avatarUrl: 'https://lh3.googleusercontent.com/a/default-user=s96-c',
    };
    saveUserToStateAndStorage(googleUser);
    return { success: true, message: 'Signed in with Google!' };
  };

  const forgotPassword = async (email: string) => {
    if (!email) {
      return { success: false, message: 'Please provide a valid email address.' };
    }
    try {
      await fetch('/api/auth/demo-forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      }).catch(() => {});
    } catch (e) {
      // ignore
    }
    return {
      success: true,
      message: `Password reset instructions have been sent to ${email}. Check your inbox!`,
    };
  };

  const updateProfile = (updatedData: Partial<UserProfile>) => {
    if (!user) return;
    const updated = { ...user, ...updatedData };
    saveUserToStateAndStorage(updated);
  };

  const updateLocation = (loc: UserLocation) => {
    if (!user) return;
    const updated = { ...user, location: loc };
    saveUserToStateAndStorage(updated);
  };

  const detectCurrentGPSLocation = async (): Promise<{ success: boolean; message: string }> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve({ success: false, message: 'Geolocation is not supported by your browser.' });
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const detectedLocation: UserLocation = {
            address: 'GPS Current Position',
            city: `Coords: ${latitude.toFixed(3)}, ${longitude.toFixed(3)}`,
            lat: latitude,
            lng: longitude,
          };
          updateLocation(detectedLocation);
          resolve({
            success: true,
            message: `Location updated to (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`,
          });
        },
        (error) => {
          console.warn('Geolocation error:', error);
          resolve({
            success: false,
            message: 'Could not access GPS location. You can enter your city manually above.',
          });
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
      );
    });
  };

  const logout = () => {
    localStorage.removeItem('goodlife_user_profile');
    setUser(null);
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isLoading,
        login,
        signUp,
        googleLogin,
        forgotPassword,
        updateProfile,
        updateLocation,
        detectCurrentGPSLocation,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
