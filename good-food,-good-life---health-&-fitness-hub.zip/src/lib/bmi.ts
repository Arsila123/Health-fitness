import { BMIMetrics, FitnessGoal, Gender, ActivityLevel } from '../types';

export function calculateBMIMetrics(
  weightKg: number,
  heightCm: number,
  age: number = 28,
  gender: Gender = 'male',
  goal: FitnessGoal = 'stay_fit',
  activityLevel: ActivityLevel = 'moderate'
): BMIMetrics {
  const heightM = heightCm / 100;
  const bmi = heightM > 0 ? Number((weightKg / (heightM * heightM)).toFixed(1)) : 22.0;

  // Category determination
  let category: 'Underweight' | 'Normal weight' | 'Overweight' | 'Obese' = 'Normal weight';
  let color = 'text-emerald-600 bg-emerald-50 border-emerald-200';

  if (bmi < 18.5) {
    category = 'Underweight';
    color = 'text-amber-600 bg-amber-50 border-amber-200';
  } else if (bmi >= 18.5 && bmi <= 24.9) {
    category = 'Normal weight';
    color = 'text-emerald-600 bg-emerald-50 border-emerald-200';
  } else if (bmi >= 25 && bmi <= 29.9) {
    category = 'Overweight';
    color = 'text-orange-600 bg-orange-50 border-orange-200';
  } else {
    category = 'Obese';
    color = 'text-rose-600 bg-rose-50 border-rose-200';
  }

  // Ideal weight range for height
  const minIdealBMI = 18.5;
  const maxIdealBMI = 24.9;
  const idealWeightMinKg = Math.round(minIdealBMI * heightM * heightM);
  const idealWeightMaxKg = Math.round(maxIdealBMI * heightM * heightM);

  // Basal Metabolic Rate (Mifflin-St Jeor Equation)
  let bmr = 10 * weightKg + 6.25 * heightCm - 5 * age;
  if (gender === 'female') {
    bmr -= 161;
  } else {
    bmr += 5;
  }
  bmr = Math.round(bmr);

  // Activity Level Multiplier
  const activityMultipliers: Record<ActivityLevel, number> = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    very_active: 1.9,
  };
  const tdee = Math.round(bmr * (activityMultipliers[activityLevel] || 1.55));

  // Goal-based Caloric Adjustment
  let targetCalories = tdee;
  if (goal === 'weight_loss') {
    targetCalories = Math.max(1200, tdee - 500);
  } else if (goal === 'weight_gain') {
    targetCalories = tdee + 500;
  } else if (goal === 'muscle_building') {
    targetCalories = tdee + 300;
  } else {
    targetCalories = tdee;
  }

  // Target Macros
  let proteinPerKg = 1.6;
  if (goal === 'muscle_building' || goal === 'weight_loss') {
    proteinPerKg = 2.0;
  } else if (goal === 'weight_gain') {
    proteinPerKg = 1.8;
  }

  const proteinG = Math.round(weightKg * proteinPerKg);
  const proteinCalories = proteinG * 4;

  const fatCalories = targetCalories * 0.25;
  const fatG = Math.round(fatCalories / 9);

  const carbCalories = Math.max(0, targetCalories - proteinCalories - fatCalories);
  const carbsG = Math.round(carbCalories / 4);

  // Recommended hydration
  const waterLiters = Number((weightKg * 0.035).toFixed(1));

  // Senior Trainer Assessment Note (12 yrs experience)
  let trainerNote = '';
  if (goal === 'weight_loss') {
    trainerNote = `Coach Marcus's Advice: At a BMI of ${bmi} (${category}), aim for a steady loss of 0.5kg/week. Prioritize high-protein budget foods (eggs, Greek yogurt, chicken breast, lentils) to preserve lean muscle while maintaining a 500 kcal deficit. Pair with 3x strength training sessions and 8,000+ daily steps.`;
  } else if (goal === 'weight_gain') {
    trainerNote = `Coach Marcus's Advice: At a BMI of ${bmi} (${category}), progressive calorie density is key. Incorporate clean budget-friendly fats like peanut butter, oats, whole milk, and eggs. Aim for a structured 300-500 kcal daily surplus with heavy compound resistance exercises.`;
  } else if (goal === 'muscle_building') {
    trainerNote = `Coach Marcus's Advice: Muscle hypertrophy requires optimized protein synthesis (${proteinG}g protein/day) and progressive overload training. Focus on budget-friendly protein stores and healthy fuel (rice, sweet potatoes, eggs) eaten within 90 minutes post-workout.`;
  } else {
    trainerNote = `Coach Marcus's Advice: Excellent! At a BMI of ${bmi} (${category}), maintenance focuses on body composition, cellular recovery, and vibrant daily energy. Keep your meals colorful with budget salad bars, fresh juices, and balanced macros.`;
  }

  return {
    bmi,
    category,
    color,
    idealWeightMinKg,
    idealWeightMaxKg,
    bmr,
    tdee,
    targetCalories,
    proteinG,
    carbsG,
    fatG,
    waterLiters,
    trainerNote,
  };
}
