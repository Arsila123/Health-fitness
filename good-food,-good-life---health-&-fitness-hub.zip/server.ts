import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Senior Fitness Trainer & Clinical Nutrition Expert System Prompt
const TRAINER_SYSTEM_PROMPT = `You are Coach Marcus Vance, a renowned Senior Fitness Trainer & Clinical Nutrition Specialist with over 12 years of hands-on experience treating and transforming client health. 
Your approach combines evidence-based exercise physiology, tailored macronutrient distribution, and realistic budget-friendly meal planning.
When advising clients:
- Speak with warm authority, practical empathy, and actionable clarity.
- Always contextualize recommendations around their specific Age, Gender, Height, Weight, BMI, and Fitness Goal (Weight Loss, Weight Gain, Muscle Building, Stay Fit).
- Focus heavily on affordable, nutrient-dense whole foods (budget-friendly healthy eating).
- Provide specific calorie & macro suggestions (Protein, Carbs, Fats) and key lifestyle rules.`;

// Senior Clinical Endocrinological & Dietary Diabetes Specialist System Prompt
const DIABETES_SYSTEM_PROMPT = `You are Dr. Elena Vance, Senior Clinical Nutrition Specialist & Glycemic Health Advisor with 15 years of clinical endocrinological dietary counseling experience.
Your focus is evidence-based Diabetes Prevention & Management, Low-Glycemic Index (GI) meal planning, glucose spike prevention, and budget-friendly grocery choices for pre-diabetic and diabetic individuals.
Always emphasize:
- Clear explanation of glycemic risk based on Fasting Glucose, Post-Meal Glucose, HbA1c, BP, BMI, and ADA risk factors.
- Low-GI (<55) budget whole foods (lentils, chia seeds, eggs, leafy greens, wild salmon/canned sardines, berries, cinnamon).
- Smart carbohydrate distribution (capping net carbs per meal, pairing carbs with dietary fiber & lean protein to flatten insulin spikes).
- Compassionate, medical-grade clarity with practical meal prep hacks.`;

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// AI Clinical Diabetes Health Assessment Endpoint
app.post('/api/diabetes-report', async (req, res) => {
  try {
    const { userProfile, riskFactors, readings } = req.body;
    const ai = getGeminiClient();

    const fasting = riskFactors?.fastingGlucoseMgDl || 95;
    const postMeal = riskFactors?.postMealGlucoseMgDl || 135;
    const hba1c = riskFactors?.hba1cPercent || 5.6;

    let defaultLevel: 'Low Risk' | 'Pre-Diabetes / Borderline' | 'Diabetes Managed' | 'High Risk / Uncontrolled' = 'Low Risk';
    let defaultScore = 2;

    if (fasting >= 126 || postMeal >= 200 || hba1c >= 6.5) {
      defaultLevel = 'High Risk / Uncontrolled';
      defaultScore = 8;
    } else if (fasting >= 100 || postMeal >= 140 || hba1c >= 5.7) {
      defaultLevel = 'Pre-Diabetes / Borderline';
      defaultScore = 5;
    }

    if (!ai) {
      return res.json({
        riskAssessment: {
          level: defaultLevel,
          score: defaultScore,
          summary: `Clinical assessment based on fasting glucose (${fasting} mg/dL) and HbA1c (${hba1c}%). Glycemic stability is key to preventing insulin resistance and metabolic fatigue.`
        },
        glycemicIndexGuideline: {
          maxCarbsPerMealG: 35,
          dailyFiberTargetG: 38,
          glycemicLoadCap: 'Low Glycemic Load (<10 per meal)'
        },
        clinicalAdvice: `### Clinical Diabetes & Glycemic Management Guidelines\n\n1. **Glucose Spike Control**: Always eat non-starchy vegetables and lean protein **before** consuming complex carbohydrates. This simple food sequencing reduces post-meal glucose spikes by up to 40%.\n2. **Low-GI Carbohydrates**: Replace refined grains (white bread, white rice) with low-GI alternatives like steel-cut oats, quinoa, lentils, and black beans.\n3. **Post-Meal Exercise**: A 10-15 minute gentle walk immediately after meals helps GLUT-4 transporters clear glucose from blood into muscle tissue without requiring excess insulin.`,
        budgetLowGiFoods: [
          { food: 'Dried Green Lentils', giRating: 28, approxPrice: '$1.49 / lb', glycemicBenefit: 'High soluble fiber stabilizes blood sugar and provides long-lasting satiety.' },
          { food: 'Whole Eggs', giRating: 0, approxPrice: '$2.99 / dozen', glycemicBenefit: 'Zero carbohydrate, protein & healthy fats prevent insulin spikes entirely.' },
          { food: 'Spinach & Kale', giRating: 15, approxPrice: '$2.49 / bag', glycemicBenefit: 'Rich in magnesium and antioxidants that improve insulin sensitivity.' },
          { food: 'Chia Seeds', giRating: 1, approxPrice: '$3.99 / lb', glycemicBenefit: 'Forms a gel in stomach that slows carbohydrate digestion and glucose absorption.' },
          { food: 'Wild Canned Sardines / Salmon', giRating: 0, approxPrice: '$2.29 / can', glycemicBenefit: 'Packed with Omega-3 fatty acids that combat systemic cellular inflammation.' }
        ],
        recommendedLowGiMeals: [
          { meal: 'Chia & Berry Power Oats', description: 'Steel-cut oats with 1 tbsp chia seeds, cinnamon, and fresh blueberries', carbsG: 28, proteinG: 14, approxCost: '$1.70' },
          { meal: 'Lentil & Avocado Protein Bowl', description: 'Warm seasoned green lentils topped with poached egg, avocado slices, and baby spinach', carbsG: 32, proteinG: 22, approxCost: '$2.50' },
          { meal: 'Salmon & Broccoli Green Salad', description: 'Flaked canned salmon over leafy greens, cucumbers, extra virgin olive oil, and lemon juice', carbsG: 8, proteinG: 28, approxCost: '$2.90' }
        ],
        warningFlags: [
          'If fasting blood glucose exceeds 180 mg/dL consistently, consult your healthcare provider.',
          'Always keep a source of fast-acting glucose (e.g. 15g carbohydrates) if experiencing hypoglycemic symptoms (shakiness, dizziness, sweating).'
        ]
      });
    }

    const contextText = `
CLIENT DIABETES HEALTH PROFILE:
Name: ${userProfile?.name || 'Member'}
Age: ${userProfile?.age || 30} | Gender: ${userProfile?.gender || 'male'} | BMI: ${userProfile?.bmi || '23.5'}
Fasting Blood Sugar: ${fasting} mg/dL
Post-Meal Blood Sugar: ${postMeal} mg/dL
HbA1c Level: ${hba1c}%
Blood Pressure: ${riskFactors?.systolicBp || 120}/${riskFactors?.diastolicBp || 80} mmHg
ADA Risk Factors: Family History (${riskFactors?.familyHistory ? 'Yes' : 'No'}), High BP (${riskFactors?.highBpHistory ? 'Yes' : 'No'}), Physical Inactivity (${riskFactors?.physicalInactivity ? 'Yes' : 'No'})
Recent Logs Count: ${readings?.length || 0}
`;

    const fullPrompt = `${contextText}

Generate a formal Clinical Diabetes & Glycemic Health Report in JSON with exact keys:
- "riskAssessment": { "level": "Low Risk" | "Pre-Diabetes / Borderline" | "Diabetes Managed" | "High Risk / Uncontrolled", "score": number (0-10), "summary": string }
- "glycemicIndexGuideline": { "maxCarbsPerMealG": number, "dailyFiberTargetG": number, "glycemicLoadCap": string }
- "clinicalAdvice": string (Markdown formatted with clinical guidelines, food sequencing, post-meal walk rules, and low-GI advice)
- "budgetLowGiFoods": array of { "food": string, "giRating": number, "approxPrice": string, "glycemicBenefit": string }
- "recommendedLowGiMeals": array of { "meal": string, "description": string, "carbsG": number, "proteinG": number, "approxCost": string }
- "warningFlags": array of string`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: fullPrompt,
      config: {
        systemInstruction: DIABETES_SYSTEM_PROMPT,
        responseMimeType: 'application/json',
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response from AI model');
    }

    const parsedData = JSON.parse(text);
    return res.json(parsedData);
  } catch (error: any) {
    console.error('Error in /api/diabetes-report:', error);
    return res.status(500).json({
      error: 'Failed to generate diabetes report',
      details: error.message,
    });
  }
});


// AI Senior Trainer Consultation Endpoint
app.post('/api/coach', async (req, res) => {
  try {
    const { userProfile, prompt } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback response if no API key is set
      return res.json({
        advice: `Welcome! As a Senior Fitness Coach with 12 years of experience, here is your core recommendation based on your profile (${userProfile?.fitnessGoal || 'Health Improvement'}): Focus on 1.6g-2.0g of protein per kg of body weight, drink 3+ liters of water daily, maintain a slight caloric deficit or surplus based on your BMI, and source clean budget-friendly foods like eggs, oats, Greek yogurt, lentils, and fresh local greens.`,
        suggestedMacros: {
          calories: userProfile?.weightKg ? Math.round(userProfile.weightKg * 30) : 2000,
          proteinG: userProfile?.weightKg ? Math.round(userProfile.weightKg * 1.8) : 120,
          carbsG: 220,
          fatG: 60,
        },
        budgetTips: [
          'Buy eggs, canned tuna, and dried lentils in bulk for cheap high-quality protein.',
          'Visit local juice shops & salad bars that offer loyalty rewards or daily $8 bowl specials.',
          'Batch cook rice and roasted root vegetables twice a week to cut food waste.'
        ]
      });
    }

    const contextText = userProfile
      ? `CLIENT PROFILE:
Name: ${userProfile.name || 'Member'}
Age: ${userProfile.age} | Gender: ${userProfile.gender}
Height: ${userProfile.heightCm} cm | Weight: ${userProfile.weightKg} kg | BMI: ${userProfile.bmi?.toFixed(1) || 'N/A'}
Fitness Goal: ${userProfile.fitnessGoal}
Activity Level: ${userProfile.activityLevel || 'Moderate'}
Location: ${userProfile.location?.city || userProfile.location?.address || 'Local Community'}
Dietary Preference: ${userProfile.dietaryPreference || 'Balanced'}
Budget Preference: ${userProfile.budgetPreference || 'Budget Friendly ($)'}
`
      : 'CLIENT PROFILE: Standard General Assessment';

    const fullPrompt = `${contextText}

CLIENT QUESTION / REQUEST:
"${prompt || 'Please give me a complete 12-year expert fitness trainer assessment, target caloric/macro guidance, budget grocery advice, and actionable daily routine.'}"

Provide a structured, encouraging, and detailed response in JSON format with:
- "advice": string (formatted in markdown, warm & professional trainer voice)
- "suggestedMacros": { "calories": number, "proteinG": number, "carbsG": number, "fatG": number }
- "budgetTips": array of string (3-4 practical budget-friendly food/grocery hacks)
- "recommendedMeals": array of { "meal": string, "description": string, "approxCost": string }`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: fullPrompt,
      config: {
        systemInstruction: TRAINER_SYSTEM_PROMPT,
        responseMimeType: 'application/json',
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response from AI model');
    }

    const parsedData = JSON.parse(text);
    return res.json(parsedData);
  } catch (error: any) {
    console.error('Error in /api/coach:', error);
    return res.status(500).json({
      error: 'Failed to generate trainer advice',
      details: error.message,
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Good Food, Good Life App running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
